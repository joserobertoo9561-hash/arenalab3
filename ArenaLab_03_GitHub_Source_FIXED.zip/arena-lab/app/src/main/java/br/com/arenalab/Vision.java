package br.com.arenalab;

import android.graphics.*;
import org.json.*;

/** Lightweight nearest-example vision with direct sampling to avoid per-frame bitmap allocations. */
public final class Vision {
    public static final int SIDE=16;

    public static double[] feature(Bitmap image,JSONObject region){
        if(region==null)region=rect(0,0,1,1);
        double l=clamp(region.optDouble("l",0)),t=clamp(region.optDouble("t",0)),r=clamp(region.optDouble("r",1)),b=clamp(region.optDouble("b",1));
        if(r<=l||b<=t){l=0;t=0;r=1;b=1;}
        double[] v=new double[SIDE*SIDE*3];
        int width=image.getWidth(),height=image.getHeight();
        for(int j=0;j<SIDE;j++)for(int i=0;i<SIDE;i++){
            double nx=l+(r-l)*(i+.5)/SIDE,ny=t+(b-t)*(j+.5)/SIDE;
            int x=Math.max(0,Math.min(width-1,(int)(nx*width))),y=Math.max(0,Math.min(height-1,(int)(ny*height)));
            int p=image.getPixel(x,y),k=(j*SIDE+i)*3;
            v[k]=Color.red(p)/255.;v[k+1]=Color.green(p)/255.;v[k+2]=Color.blue(p)/255.;
        }
        return v;
    }

    private static double clamp(double v){return Math.max(0,Math.min(1,v));}
    public static JSONObject rect(double l,double t,double r,double b){JSONObject o=new JSONObject();Store.put(o,"l",l);Store.put(o,"t",t);Store.put(o,"r",r);Store.put(o,"b",b);return o;}
    public static JSONArray encode(double[] f){JSONArray a=new JSONArray();for(double v:f){try{a.put(v);}catch(JSONException e){a.put(0);}}return a;}
    public static double similarity(double[] f,JSONArray reference){if(reference==null||f.length!=reference.length())return 0;double[]r=new double[reference.length()];for(int i=0;i<r.length;i++)r[i]=reference.optDouble(i,0);return Core.imageSimilarity(f,r);}
    public static final class Match {public String label="unknown";public double confidence,margin;}

    public static Match scene(Bitmap img,JSONArray examples){
        Match m=new Match();double second=0;
        for(int i=0;i<examples.length();i++){JSONObject ex=examples.optJSONObject(i);if(ex==null||!"scene".equals(ex.optString("kind")))continue;
            if(!Core.sameAspect((double)img.getWidth()/img.getHeight(),ex.optDouble("aspect")))continue;
            double score=similarity(feature(img,ex.optJSONObject("region")),ex.optJSONArray("feature"));
            if(score>m.confidence){if(!m.label.equals(ex.optString("label")))second=m.confidence;m.confidence=score;m.label=ex.optString("label");}
            else if(!m.label.equals(ex.optString("label")))second=Math.max(second,score);
        }
        m.margin=m.confidence-second;return m;
    }

    public static Match card(Bitmap img,JSONObject region,JSONArray examples){
        double[] f=feature(img,region);Match m=new Match();double second=0;
        for(int i=0;i<examples.length();i++){JSONObject ex=examples.optJSONObject(i);if(ex==null||!"card".equals(ex.optString("kind")))continue;
            double score=similarity(f,ex.optJSONArray("feature"));
            if(score>m.confidence){if(!m.label.equals(ex.optString("label")))second=m.confidence;m.confidence=score;m.label=ex.optString("label");}
            else if(!m.label.equals(ex.optString("label")))second=Math.max(second,score);
        }
        m.margin=m.confidence-second;return m;
    }

    /** Estimate the purple fill over several scan lines instead of trusting one row. */
    public static double elixir(Bitmap img,JSONObject r){
        if(!validRect(r))return -1;
        int width=img.getWidth(),height=img.getHeight();
        int l=Math.max(0,(int)(r.optDouble("l")*width)),right=Math.min(width,(int)(r.optDouble("r")*width));
        int top=Math.max(0,(int)(r.optDouble("t")*height)),bottom=Math.min(height,(int)(r.optDouble("b")*height));
        if(right-l<10||bottom-top<1)return -1;
        int[] ys={top+(bottom-top)/3,top+(bottom-top)/2,top+(bottom-top)*2/3};
        double sum=0;int rows=0;
        for(int y:ys){int filled=0,total=0;for(int x=l;x<right;x+=Math.max(1,(right-l)/180)){
            int p=img.getPixel(x,Math.max(0,Math.min(height-1,y)));int red=Color.red(p),g=Color.green(p),blue=Color.blue(p);
            if(red>100&&blue>90&&red>g*1.22&&blue>g*1.16)filled++;total++;
        }if(total>8){sum+=(double)filled/total;rows++;}}
        if(rows==0)return -1;return Math.max(0,Math.min(10,10.*sum/rows));
    }

    /**
     * Detect narrow red health-bar-like runs in our half. v0.3 also weights components
     * closer to our towers more heavily so the planner can distinguish pressure from urgency.
     */
    public static void threats(Bitmap img,JSONObject arena,Core.State s){
        if(!validRect(arena))return;
        double l=arena.optDouble("l"),r=arena.optDouble("r"),t=arena.optDouble("t"),b=arena.optDouble("b"),mid=(l+r)*.5;
        int width=img.getWidth(),height=img.getHeight(),step=Math.max(1,width/260),totalL=0,totalR=0;
        double sumLX=0,sumLY=0,sumRX=0,sumRY=0,weightedL=0,weightedR=0;
        int startY=(int)((t+(b-t)*.48)*height),endY=(int)(b*height);
        for(int y=startY;y<endY;y+=step*2){
            int run=0,start=0;
            for(int x=(int)(l*width);x<(int)(r*width);x+=step){
                int p=img.getPixel(Math.max(0,Math.min(width-1,x)),Math.max(0,Math.min(height-1,y)));
                int red=Color.red(p),g=Color.green(p),blue=Color.blue(p);boolean hit=red>145&&red>g*1.65&&red>blue*1.42;
                if(hit){if(run==0)start=x;run++;}
                if(!hit||x+step>=(int)(r*width)){
                    if(run>=3&&run<=25){double px=(start+run*step*.5)/width,py=(double)y/height;
                        double arenaY=(py-t)/Math.max(.001,b-t);double proximity=Math.max(0,Math.min(1,(arenaY-.48)/.52));
                        if(px<mid){totalL++;sumLX+=px;sumLY+=py;weightedL+=.35+.65*proximity;}
                        else{totalR++;sumRX+=px;sumRY+=py;weightedR+=.35+.65*proximity;}
                    }run=0;
                }
            }
        }
        s.leftThreat=totalL*.001;s.rightThreat=totalR*.001;
        s.leftUrgency=Math.min(1,weightedL*.12);s.rightUrgency=Math.min(1,weightedR*.12);
        if(totalL>0){s.leftX=(sumLX/totalL-l)/(r-l);s.leftY=(sumLY/totalL-t)/(b-t);}
        if(totalR>0){s.rightX=(sumRX/totalR-l)/(r-l);s.rightY=(sumRY/totalR-t)/(b-t);}
    }

    public static boolean validRect(JSONObject r){return r!=null&&r.optDouble("l",-1)>=0&&r.optDouble("t",-1)>=0&&r.optDouble("r",2)<=1&&r.optDouble("b",2)<=1&&r.optDouble("r")-r.optDouble("l")>.012&&r.optDouble("b")-r.optDouble("t")>.008;}
}
