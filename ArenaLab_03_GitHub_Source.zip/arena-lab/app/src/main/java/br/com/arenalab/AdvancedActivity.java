package br.com.arenalab;

import android.app.*;
import android.content.*;
import android.os.*;
import android.provider.Settings;
import android.widget.*;
import org.json.*;
import java.util.*;

public final class AdvancedActivity extends Activity {
    private Store store;private int page;
    @Override public void onCreate(Bundle b){super.onCreate(b);store=new Store(this);show(0);}
    @Override public void onResume(){super.onResume();if(store!=null)show(page);}
    private void show(int which){
        page=which;LinearLayout root=Ui.page(this);
        Ui.heading(root,"Arena Lab · Avançado","0.3 · calibração, deck, limites e procedimentos");
        LinearLayout nav=new LinearLayout(this);root.addView(nav);
        String[] names={"Sessão","Deck","Visão","Menus"};
        for(int i=0;i<names.length;i++){final int p=i;Button b=new Button(this);b.setText(names[i]);b.setTextSize(12);b.setAllCaps(false);b.setTextColor(i==which?Ui.ACCENT:Ui.TEXT);nav.addView(b,new LinearLayout.LayoutParams(0,Ui.dp(this,48),1));b.setOnClickListener(v->show(p));}
        if(which==0)session(root);else if(which==1)deck(root);else if(which==2)vision(root);else procedures(root);
    }
    private void session(LinearLayout root){
        JSONObject c=store.load();LinearLayout intro=Ui.card(root);
        intro.addView(Ui.text(this,"Primeiro ensine. Depois teste.",20,Ui.TEXT));
        intro.addView(Ui.text(this,"O piloto usa percepção visual, memória temporal e uma política explicável. Esta área existe para calibração e limites; o uso normal fica no painel principal.",14,Ui.MUTED));
        intro.addView(Ui.text(this,"Automação é proibida pela Supercell e pode causar banimento. A conta principal não tem isolamento garantido.",13,Ui.ACCENT));
        LinearLayout connection=Ui.card(root);connection.addView(Ui.text(this,ArenaService.instance==null?"Serviço desativado":"Serviço conectado",18,Ui.TEXT));
        connection.addView(Ui.text(this,"A acessibilidade permite ler imagens e tocar na tela. O agente verifica o pacote do Clash antes de capturar ou agir. O piloto não precisa de internet para jogar. A internet é usada apenas para catálogo e, se você configurar a IA conectada, conversa/pesquisa web. O piloto de partida continua local e não usa senha ou Supercell ID.",13,Ui.MUTED));
        Ui.button(connection,"Abrir ajustes de acessibilidade",()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        CheckBox execute=Ui.check(connection,"Executar gestos nesta sessão",false);
        Ui.button(connection,"Abrir Clash e iniciar",()->{
            if(ArenaService.instance==null){Ui.message(this,"Ative o serviço","Nos ajustes de acessibilidade, ative Arena Lab e volte aqui.");return;}
            if(execute.isChecked()){String issue=ArenaService.readiness(store);if(!issue.isEmpty()){Ui.message(this,"Calibração incompleta",issue);return;}}
            Intent launch=getPackageManager().getLaunchIntentForPackage(ArenaService.TARGET);
            if(launch==null){Ui.message(this,"Clash não encontrado","Esta versão procura o pacote com.supercell.clashroyale.");return;}
            startActivity(launch);ArenaService.instance.startSession(execute.isChecked());
        });
        Ui.button(connection,"Parar agora",()->{if(ArenaService.instance!=null)ArenaService.instance.stopSession("Parado pelo usuário",true);});
        LinearLayout settings=Ui.card(root);
        EditText limit=Ui.field(settings,"Máximo de partidas na sessão (1 a 50)",""+c.optInt("roundLimit",5),true);
        EditText minutes=Ui.field(settings,"Duração máxima em minutos (1 a 180)",""+c.optInt("minutes",30),true);
        EditText confidence=Ui.field(settings,"Confiança mínima em % (82 a 99)",""+c.optInt("threshold",92),true);
        EditText gold=Ui.field(settings,"Ouro informado por você", ""+c.optInt("gold",0),true);
        EditText budget=Ui.field(settings,"Limite de ouro para melhorias por sessão", ""+c.optInt("goldBudget",0),true);
        CheckBox autoDeck=Ui.check(settings,"Equipar o deck por procedimentos ensinados",c.optBoolean("autoDeck"));
        CheckBox upgrades=Ui.check(settings,"Melhorar cartas por procedimentos ensinados",c.optBoolean("autoUpgrade"));
        settings.addView(Ui.text(this,"O saldo e os custos são informados manualmente. O agente só usa procedimentos de melhoria que você ensinou; não interpreta lojas, gemas ou pagamentos. Cada melhoria é tentada uma vez por sessão.",12,Ui.MUTED));
        Ui.button(settings,"Salvar limites",()->{JSONObject o=store.load();Store.put(o,"roundLimit",Math.max(1,Math.min(50,Ui.integer(limit,5))));Store.put(o,"minutes",Math.max(1,Math.min(180,Ui.integer(minutes,30))));Store.put(o,"threshold",Math.max(82,Math.min(99,Ui.integer(confidence,92))));Store.put(o,"gold",Ui.integer(gold,0));Store.put(o,"goldBudget",Ui.integer(budget,0));Store.put(o,"autoDeck",autoDeck.isChecked());Store.put(o,"autoUpgrade",upgrades.isChecked());store.save(o);show(0);});
        Secrets secrets=new Secrets(this);LinearLayout ai=Ui.card(root);ai.addView(Ui.text(this,"Arena AI conectada",20,Ui.TEXT));
        ai.addView(Ui.text(this,secrets.hasApiKey()?"✓ Chave configurada · modelo "+c.optString("aiModel","gpt-6-astra"):"○ Opcional · sem chave configurada",14,secrets.hasApiKey()?Ui.ACCENT:Ui.MUTED));
        ai.addView(Ui.text(this,"Com sua própria chave, o chat usa a Responses API e pode pesquisar a web quando você pede meta. A chave fica criptografada pelo Android Keystore. Em um app cliente nenhuma chave é absolutamente irrecuperável; use limites de gasto na sua conta de API.",12,Ui.MUTED));
        Ui.button(ai,"Configurar IA conectada",()->configureAi());
        if(secrets.hasApiKey())Ui.secondaryButton(ai,"Apagar chave deste aparelho",()->{secrets.clearApiKey();show(0);});
        LinearLayout stats=Ui.card(root);stats.addView(Ui.text(this,"Resultados reconhecidos: "+c.optInt("wins")+" vitórias · "+c.optInt("losses")+" derrotas",16,Ui.TEXT));
        stats.addView(Ui.text(this,"Só conta resultados vistos após uma partida. Esses números não representam desempenho validado.",12,Ui.MUTED));
        Ui.button(stats,"Ver registro da sessão",()->Ui.message(this,"Registro",store.logs()));
        Ui.button(stats,"Ver telemetria de decisões",()->Ui.message(this,"Telemetria",store.telemetryTail()));
    }
    private void configureAi(){
        Secrets secrets=new Secrets(this);JSONObject c=store.load();LinearLayout p=Ui.column(this);p.setPadding(Ui.dp(this,18),Ui.dp(this,10),Ui.dp(this,18),0);
        EditText key=Ui.field(p,"OpenAI API key (vazio mantém a atual)","",false);key.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        EditText model=Ui.field(p,"Modelo",c.optString("aiModel","gpt-6-astra"),false);p.addView(Ui.text(this,"Sugestão: gpt-6-astra para equilíbrio. Você pode trocar o identificador se sua conta de API tiver outro modelo disponível.",12,Ui.MUTED));
        new AlertDialog.Builder(this).setTitle("IA conectada").setView(p).setNegativeButton("Cancelar",null).setPositiveButton("Salvar",(d,w)->{try{String k=key.getText().toString().trim();if(!k.isEmpty())secrets.saveApiKey(k);JSONObject o=store.load();String m=model.getText().toString().trim();Store.put(o,"aiModel",m.isEmpty()?"gpt-6-astra":m);store.save(o);show(0);}catch(Exception e){Ui.message(this,"Não consegui salvar",e.getMessage());}}).show();
    }

    private void deck(LinearLayout root){
        List<Core.Card> current=store.deck();LinearLayout box=Ui.card(root);
        if(current.size()==8){StringBuilder names=new StringBuilder();for(Core.Card card:current)names.append("• ").append(card.name).append(" · ").append(card.elixir).append("\n");box.addView(Ui.text(this,names.toString().trim(),16,Ui.TEXT));box.addView(Ui.text(this,String.format(Locale.ROOT,"Elixir médio: %.2f",Core.average(current)),14,Ui.ACCENT));}
        else box.addView(Ui.text(this,"Marque pelo menos 8 cartas disponíveis na coleção abaixo.",16,Ui.TEXT));
        box.addView(Ui.text(this,"O montador equilibra papéis, custo e níveis informados. O catálogo é inicial; heróis, evoluções e mudanças recentes de atributos não estão modelados.",13,Ui.MUTED));
        Ui.button(box,"Montar deck com minhas cartas",()->{List<Core.Card>d=Core.buildDeck(store.cards());if(d.size()!=8){Ui.message(this,"Faltam cartas","Marque pelo menos 8 cartas disponíveis.");return;}store.saveDeck(d);show(1);});
        Ui.button(box,"Já equipei este deck no Clash",()->{if(store.deck().size()!=8)return;JSONObject o=store.load();Store.put(o,"deckApplied",true);store.save(o);Ui.message(this,"Deck registrado","A declaração permite iniciar partidas sem a rotina automática de equipar. O aplicativo não conferiu sua coleção no servidor.");});
        for(Core.Card card:store.cards()){
            LinearLayout row=Ui.card(root);CheckBox owned=Ui.check(row,card.name+" · "+card.elixir+" elixir",card.owned);
            owned.setOnCheckedChangeListener((b,v)->{card.owned=v;store.saveCard(card);JSONObject o=store.load();Store.put(o,"deckApplied",false);store.save(o);});
            row.addView(Ui.text(this,"Nível informado: "+card.level+" · melhoria: "+(card.ready?card.gold+" ouro":"não disponível"),12,Ui.MUTED));
            Ui.button(row,"Editar nível e melhoria",()->editCard(card));
        }
    }
    private void editCard(Core.Card card){
        LinearLayout p=Ui.column(this);p.setPadding(Ui.dp(this,20),Ui.dp(this,12),Ui.dp(this,20),0);
        EditText level=Ui.field(p,"Nível exibido no jogo",""+card.level,true);
        EditText gold=Ui.field(p,"Custo da próxima melhoria em ouro",""+card.gold,true);
        CheckBox ready=Ui.check(p,"Tenho cartas suficientes para melhorar",card.ready);
        new AlertDialog.Builder(this).setTitle(card.name).setView(p).setNegativeButton("Cancelar",null).setPositiveButton("Salvar",(d,w)->{card.level=Math.max(1,Math.min(16,Ui.integer(level,1)));card.gold=Ui.integer(gold,0);card.ready=ready.isChecked();store.saveCard(card);show(1);}).show();
    }
    private void vision(LinearLayout root){
        LinearLayout box=Ui.card(root);box.addView(Ui.text(this,"Ensinar no próprio celular",20,Ui.TEXT));
        box.addView(Ui.text(this,"1. Inicie uma sessão no modo observar.\n2. No Clash, use CAPTURAR no painel flutuante.\n3. Marque uma região na imagem e salve o exemplo.\n4. Repita para início, partida, vitória, derrota e as 8 cartas.\n5. Marque arena, quatro cartas da mão e a barra de elixir.",14,Ui.MUTED));
        box.addView(Ui.text(this,"Nas telas, marque uma parte estável e exclusiva, como o título ou um ícone fixo. Nas cartas, marque só a ilustração, sem borda, custo ou número. As quatro regiões da mão devem recortar a mesma parte das ilustrações.",13,Ui.MUTED));
        JSONObject layout=store.load().optJSONObject("layout");
        String[] keys={"arena","hand0","hand1","hand2","hand3","elixir"};String[] labels={"Arena","Carta 1","Carta 2","Carta 3","Carta 4","Elixir"};
        for(int i=0;i<keys.length;i++)box.addView(Ui.text(this,(layout!=null&&Vision.validRect(layout.optJSONObject(keys[i]))?"✓ ":"○ ")+labels[i],14,Ui.TEXT));
        JSONArray templates=store.templates();Map<String,Integer>counts=new TreeMap<>();
        for(int i=0;i<templates.length();i++){JSONObject t=templates.optJSONObject(i);if(t==null)continue;String name=t.optString("kind")+" / "+t.optString("label");counts.put(name,counts.containsKey(name)?counts.get(name)+1:1);}
        LinearLayout examples=Ui.card(root);examples.addView(Ui.text(this,"Exemplos salvos: "+templates.length(),18,Ui.TEXT));
        for(String key:counts.keySet())examples.addView(Ui.text(this,key+" · "+counts.get(key),13,Ui.MUTED));
        Ui.button(examples,"Apagar exemplos e áreas",()->new AlertDialog.Builder(this).setTitle("Apagar calibração?").setMessage("As cartas e o deck serão mantidos. Será necessário ensinar as imagens e áreas novamente.").setNegativeButton("Cancelar",null).setPositiveButton("Apagar",(d,w)->{JSONObject o=store.load();o.remove("templates");o.remove("layout");store.save(o);show(2);}).show());
    }
    private void procedures(LinearLayout root){
        LinearLayout box=Ui.card(root);box.addView(Ui.text(this,"Menu também precisa de exemplos",20,Ui.TEXT));
        box.addView(Ui.text(this,"Cada procedimento contém passos com uma região de reconhecimento e um local de toque. Capture a tela, ensine o passo, volte ao Clash e avance manualmente para ensinar o próximo. Termine com um passo de verificação, sem toque.",14,Ui.MUTED));
        box.addView(Ui.text(this,"Procedimentos: iniciar partida, sair do resultado, equipar uma carta em um slot e melhorar uma carta com ouro. Para melhorias, a região de reconhecimento precisa incluir o custo em ouro. Ensine a verificação final depois da mudança de nível. Lojas, gemas e pagamentos ficam fora deste protótipo.",13,Ui.MUTED));
        box.addView(Ui.text(this,"Se uma imagem não conferir, o procedimento para. A rotina de deck só roda quando todos os 8 procedimentos existem; depois de verificar cada sequência, o agente registra o deck como equipado.",13,Ui.MUTED));
        for(String name:store.procedureNames()){LinearLayout p=Ui.card(root);p.addView(Ui.text(this,name+" · "+store.procedure(name).length()+" passos",15,Ui.TEXT));Ui.button(p,"Apagar procedimento",()->{store.eraseProcedure(name);show(3);});}
    }
}
