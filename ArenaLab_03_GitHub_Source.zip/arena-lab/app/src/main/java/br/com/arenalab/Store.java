package br.com.arenalab;

import android.content.Context;
import org.json.*;
import java.util.*;
import java.io.*;

public final class Store {
    private final Context ctx;
    public Store(Context ctx){this.ctx=ctx.getApplicationContext();}
    public JSONObject load(){try{return new JSONObject(ctx.getSharedPreferences("lab",0).getString("config","{}"));}catch(Exception e){return new JSONObject();}}
    public void save(JSONObject obj){ctx.getSharedPreferences("lab",0).edit().putString("config",obj.toString()).apply();}
    public static void put(JSONObject o,String key,Object value){try{o.put(key,value);}catch(JSONException e){throw new IllegalArgumentException(e);}}

    /** remoteCatalog is reserved for a future signed/sanitized catalog sync; local catalog remains the fallback. */
    public List<Core.Card> cards(){
        JSONObject conf=load();List<Core.Card> cards=new ArrayList<>();JSONArray remote=conf.optJSONArray("remoteCatalog");
        if(remote!=null&&remote.length()>=8){for(int i=0;i<remote.length();i++){JSONObject r=remote.optJSONObject(i);if(r==null)continue;String id=r.optString("id"),name=r.optString("name");int elixir=r.optInt("elixir",-1);if(id.isEmpty()||name.isEmpty()||elixir<0||elixir>10)continue;cards.add(new Core.Card(id,name,elixir,r.optInt("roles")));}}
        if(cards.size()<8)cards=Core.catalog();
        JSONObject all=conf.optJSONObject("cards");
        if(all!=null)for(Core.Card c:cards){JSONObject v=all.optJSONObject(c.id);if(v!=null){c.owned=v.optBoolean("owned");c.level=v.optInt("level",1);c.ready=v.optBoolean("ready");c.gold=v.optInt("gold",0);}}
        return cards;
    }
    public void saveCard(Core.Card c){JSONObject conf=load(),all=conf.optJSONObject("cards");if(all==null)all=new JSONObject();JSONObject v=new JSONObject();put(v,"owned",c.owned);put(v,"level",c.level);put(v,"ready",c.ready);put(v,"gold",c.gold);put(all,c.id,v);put(conf,"cards",all);save(conf);}
    public List<Core.Card> deck(){List<Core.Card> all=cards(),deck=new ArrayList<>();JSONArray ids=load().optJSONArray("deck");if(ids!=null)for(int i=0;i<ids.length();i++){Core.Card c=Core.byId(all,ids.optString(i));if(c!=null&&!deck.contains(c)&&c.owned)deck.add(c);}return deck;}
    public void saveDeck(List<Core.Card> cards){JSONObject o=load();JSONArray a=new JSONArray();for(Core.Card c:cards)a.put(c.id);put(o,"deck",a);put(o,"deckApplied",false);save(o);}
    public JSONArray templates(){JSONArray a=load().optJSONArray("templates");return a==null?new JSONArray():a;}
    public void addTemplate(JSONObject t){JSONObject o=load();JSONArray a=templates();a.put(t);put(o,"templates",a);save(o);}
    public JSONArray procedure(String name){JSONObject p=load().optJSONObject("procedures");JSONArray a=p==null?null:p.optJSONArray(name);return a==null?new JSONArray():a;}
    public Set<String> procedureNames(){Set<String>s=new TreeSet<>();JSONObject p=load().optJSONObject("procedures");if(p!=null){Iterator<String>k=p.keys();while(k.hasNext())s.add(k.next());}return s;}
    public void addStep(String name,JSONObject step){JSONObject o=load(),p=o.optJSONObject("procedures");if(p==null)p=new JSONObject();JSONArray a=p.optJSONArray(name);if(a==null)a=new JSONArray();a.put(step);put(p,name,a);put(o,"procedures",p);save(o);}
    public void eraseProcedure(String name){JSONObject o=load(),p=o.optJSONObject("procedures");if(p!=null){p.remove(name);save(o);}}

    public String strategy(){return Core.policy(load().optString("strategy","balanced")).id;}
    public void setStrategy(String strategy){JSONObject o=load();put(o,"strategy",Core.policy(strategy).id);save(o);}
    public int style(){String s=strategy();return "aggressive".equals(s)?Core.STYLE_AGGRESSIVE:"defensive".equals(s)?Core.STYLE_DEFENSIVE:Core.STYLE_BALANCED;}
    public void setStyle(int style){setStrategy(Core.strategyId(style));}
    public synchronized void runtime(String status){ctx.getSharedPreferences("runtime",0).edit().putString("status",status).apply();}
    public String runtime(){return ctx.getSharedPreferences("runtime",0).getString("status","Agente parado");}
    public synchronized void decision(String text){ctx.getSharedPreferences("runtime",0).edit().putString("decision",text).apply();}
    public String decision(){return ctx.getSharedPreferences("runtime",0).getString("decision","Ainda não fiz uma jogada nesta sessão.");}

    public synchronized void log(String message){try{File f=new File(ctx.getFilesDir(),"session.log");if(f.length()>200000)new FileOutputStream(f).close();FileWriter w=new FileWriter(f,true);w.write(new java.text.SimpleDateFormat("HH:mm:ss",Locale.ROOT).format(new Date())+" "+message+"\n");w.close();}catch(IOException ignored){}}
    public String logs(){try{byte[]b=java.nio.file.Files.readAllBytes(new File(ctx.getFilesDir(),"session.log").toPath());String s=new String(b,"UTF-8");return s.substring(Math.max(0,s.length()-14000));}catch(Exception e){return "Nenhuma sessão registrada.";}}
    public void recordResult(boolean win){JSONObject o=load();put(o,win?"wins":"losses",o.optInt(win?"wins":"losses")+1);save(o);}
    public synchronized void telemetry(JSONObject event){try{put(event,"time",System.currentTimeMillis());File f=new File(ctx.getFilesDir(),"telemetry.ndjson");if(f.length()>600000)new FileOutputStream(f).close();FileWriter w=new FileWriter(f,true);w.write(event.toString());w.write("\n");w.close();}catch(Exception ignored){}}
    public String telemetryTail(){try{byte[]b=java.nio.file.Files.readAllBytes(new File(ctx.getFilesDir(),"telemetry.ndjson").toPath());String s=new String(b,"UTF-8");return s.substring(Math.max(0,s.length()-16000));}catch(Exception e){return "Nenhuma telemetria registrada.";}}
}
