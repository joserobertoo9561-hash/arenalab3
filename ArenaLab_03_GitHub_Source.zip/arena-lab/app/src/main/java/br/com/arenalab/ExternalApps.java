package br.com.arenalab;

import android.app.SearchManager;
import android.content.*;
import android.net.Uri;
import android.provider.MediaStore;

/** User-requested handoff to other apps. Accessibility gestures remain Clash-only. */
public final class ExternalApps {
    private static boolean launch(Context c,Intent i){try{i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);c.startActivity(i);return true;}catch(Exception e){return false;}}
    public static boolean browser(Context c,String query){Uri u=Uri.parse("https://www.google.com/search?q="+Uri.encode(query==null?"":query));if(launch(c,new Intent(Intent.ACTION_VIEW,u).setPackage("com.android.chrome")))return true;return launch(c,new Intent(Intent.ACTION_VIEW,u));}
    public static boolean youtube(Context c,String query){Uri u=Uri.parse("https://www.youtube.com/results?search_query="+Uri.encode(query==null?"":query));if(launch(c,new Intent(Intent.ACTION_VIEW,u).setPackage("com.google.android.youtube")))return true;return launch(c,new Intent(Intent.ACTION_VIEW,u));}
    public static boolean spotify(Context c,String query){String q=query==null?"":query.trim();Intent play=new Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH);play.setPackage("com.spotify.music");play.putExtra(MediaStore.EXTRA_MEDIA_FOCUS,"vnd.android.cursor.item/audio");play.putExtra(SearchManager.QUERY,q);if(launch(c,play))return true;Intent search=new Intent(Intent.ACTION_VIEW,Uri.parse("spotify:search:"+Uri.encode(q))).setPackage("com.spotify.music");if(launch(c,search))return true;return launch(c,new Intent(Intent.ACTION_VIEW,Uri.parse("https://open.spotify.com/search/"+Uri.encode(q))));}
}
