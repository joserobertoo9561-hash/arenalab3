package br.com.arenalab;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Device-bound encrypted storage for the optional personal API key. */
public final class Secrets {
    private static final String ALIAS="arena_lab_ai_v1",PREF="arena_lab_secrets",VALUE="api_key",IV="api_iv";
    private final Context ctx;
    public Secrets(Context c){ctx=c.getApplicationContext();}
    private SecretKey key() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);java.security.Key k=ks.getKey(ALIAS,null);if(k instanceof SecretKey)return (SecretKey)k;
        KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        gen.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
        return gen.generateKey();
    }
    public boolean hasApiKey(){return !ctx.getSharedPreferences(PREF,0).getString(VALUE,"").isEmpty();}
    public void clearApiKey(){ctx.getSharedPreferences(PREF,0).edit().remove(VALUE).remove(IV).apply();}
    public void saveApiKey(String value) throws Exception {
        if(value==null||value.trim().isEmpty()){clearApiKey();return;}Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());byte[] enc=c.doFinal(value.trim().getBytes("UTF-8"));
        ctx.getSharedPreferences(PREF,0).edit().putString(VALUE,Base64.encodeToString(enc,Base64.NO_WRAP)).putString(IV,Base64.encodeToString(c.getIV(),Base64.NO_WRAP)).apply();
    }
    public String apiKey(){try{String v=ctx.getSharedPreferences(PREF,0).getString(VALUE,""),iv=ctx.getSharedPreferences(PREF,0).getString(IV,"");if(v.isEmpty()||iv.isEmpty())return "";Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(iv,Base64.NO_WRAP)));return new String(c.doFinal(Base64.decode(v,Base64.NO_WRAP)),"UTF-8");}catch(Exception e){return "";}}
}
