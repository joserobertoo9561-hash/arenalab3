package br.com.arenalab;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.util.*;

public final class TeachActivity extends Activity {
    private Store store;private Bitmap image;private MarkView mark;private Spinner type,option;
    private CheckBox proof;private LinearLayout opts;private final List<String> values=new ArrayList<>();
    private static final String[] TYPES={"Reconhecer uma tela","Reconhecer uma carta","Área da arena","Ilustração da carta 1","Ilustração da carta 2","Ilustração da carta 3","Ilustração da carta 4","Barra de elixir","Passo de procedimento"};
    @Override public void onCreate(Bundle b){super.onCreate(b);store=new Store(this);image=BitmapFactory.decodeFile(new File(getCacheDir(),"teach.png").getAbsolutePath());if(image==null){finish();return;}
        LinearLayout p=Ui.page(this);Ui.heading(p,"Ensinar visão","Arraste um retângulo sobre a região desejada.");
        mark=new MarkView();p.addView(mark,new LinearLayout.LayoutParams(-1,Ui.dp(this,380)));
        type=new Spinner(this);type.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,TYPES));p.addView(type);
        opts=Ui.column(this);p.addView(opts);type.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?>v){}public void onItemSelected(android.widget.AdapterView<?>p,View v,int position,long id){refreshOptions(position);}});
        Ui.button(p,"Marcar o local do toque",()->{mark.pointMode=true;Ui.message(this,"Local do toque","Toque uma vez na imagem. Depois, se precisar, use o botão de região para voltar a arrastar o retângulo.");});
        Ui.button(p,"Marcar região de reconhecimento",()->{mark.pointMode=false;});
        Ui.button(p,"Salvar exemplo / passo",()->save());
        Ui.button(p,"Voltar ao Clash",()->backToGame());
    }
    private void refreshOptions(int index){
        opts.removeAllViews();values.clear();List<String>labels=new ArrayList<>();option=null;proof=null;
        if(index==0){Collections.addAll(values,"home","battle","victory","loss");Collections.addAll(labels,"Tela inicial","Partida","Vitória","Derrota");}
        else if(index==1){for(Core.Card c:store.cards())if(c.owned){values.add(c.id);labels.add(c.name);}}
        else if(index==8){
            values.add("battle.start");labels.add("Iniciar partida");values.add("result.dismiss");labels.add("Sair do resultado");
            List<Core.Card>deck=store.deck();for(int slot=0;slot<deck.size();slot++){Core.Card c=deck.get(slot);values.add("equip."+c.id+"."+slot);labels.add("Equipar "+c.name+" no slot "+(slot+1));}
            for(Core.Card c:deck){values.add("upgrade."+c.id);labels.add("Melhorar "+c.name+" com ouro");}
        }
        if(!labels.isEmpty()){option=new Spinner(this);option.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,labels));opts.addView(option);}
        if(index==8){proof=Ui.check(opts,"Último passo: apenas verificar, sem toque",false);opts.addView(Ui.text(this,"Os passos são acrescentados na ordem. Uma sequência precisa terminar com a verificação da tela final. Na melhoria, inclua o preço em ouro no retângulo antes de confirmar.",12,Ui.MUTED));}
    }
    private void save(){
        JSONObject region=mark.region();if(!Vision.validRect(region)){Ui.message(this,"Marque a região","Arraste um retângulo com uma área visível na imagem.");return;}
        int index=type.getSelectedItemPosition();double aspect=(double)image.getWidth()/image.getHeight();
        if(index==0||index==1||index==8){double[] feature=Vision.feature(image,region);if(Core.imageSimilarity(feature,feature)<.99){Ui.message(this,"Faltam detalhes","Uma cor lisa não identifica a tela. Marque uma região com texto, ícone ou ilustração reconhecível.");return;}}
        if(index==0||index==1){if(values.isEmpty()||option==null){Ui.message(this,"Coleção vazia","Marque suas cartas na aba Deck.");return;}
            JSONObject t=new JSONObject();Store.put(t,"kind",index==0?"scene":"card");Store.put(t,"label",values.get(option.getSelectedItemPosition()));Store.put(t,"region",region);Store.put(t,"aspect",aspect);Store.put(t,"feature",Vision.encode(Vision.feature(image,region)));store.addTemplate(t);
        }else if(index>=2&&index<=7){
            String[] keys={"arena","hand0","hand1","hand2","hand3","elixir"};JSONObject o=store.load(),layout=o.optJSONObject("layout");
            if(layout==null||!Core.sameAspect(layout.optDouble("aspect",aspect),aspect))layout=new JSONObject();
            Store.put(layout,keys[index-2],region);Store.put(layout,"aspect",aspect);Store.put(o,"layout",layout);store.save(o);
        }else if(index==8){
            boolean verify=proof!=null&&proof.isChecked();if(!verify&&(mark.px<0||!Core.safePoint(mark.px,mark.py))){Ui.message(this,"Falta o toque","Use Marcar o local do toque e toque na imagem, ou marque verificação final.");return;}
            String name=values.get(option.getSelectedItemPosition());JSONArray existing=store.procedure(name);
            if(existing.length()>0&&existing.optJSONObject(existing.length()-1).optBoolean("verify")){Ui.message(this,"Sequência já finalizada","Apague o procedimento na aba Menus antes de ensinar novamente.");return;}
            JSONObject step=new JSONObject();Store.put(step,"region",region);Store.put(step,"aspect",aspect);Store.put(step,"feature",Vision.encode(Vision.feature(image,region)));Store.put(step,"verify",verify);Store.put(step,"x",mark.px);Store.put(step,"y",mark.py);store.addStep(name,step);
        }
        Ui.message(this,"Salvo","O exemplo ficou no aparelho. Volte ao Clash para capturar outra tela, ou à aba Sessão para revisar a calibração.");
    }
    private void backToGame(){Intent i=getPackageManager().getLaunchIntentForPackage(ArenaService.TARGET);if(i!=null)startActivity(i);if(ArenaService.instance!=null)ArenaService.instance.showPanel();finish();}
    @Override public void onDestroy(){super.onDestroy();if(image!=null&&!image.isRecycled())image.recycle();}
    private final class MarkView extends View {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);private float scale,ox,oy,sx,sy,ex,ey;private boolean selected,pointMode;private double px=-1,py=-1;
        MarkView(){super(TeachActivity.this);setBackgroundColor(Ui.PANEL);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);scale=Math.min((float)getWidth()/image.getWidth(),(float)getHeight()/image.getHeight());ox=(getWidth()-image.getWidth()*scale)/2;oy=(getHeight()-image.getHeight()*scale)/2;
            c.drawBitmap(image,null,new RectF(ox,oy,ox+image.getWidth()*scale,oy+image.getHeight()*scale),p);
            if(selected){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Ui.dp(TeachActivity.this,2));p.setColor(Ui.ACCENT);c.drawRect(Math.min(sx,ex),Math.min(sy,ey),Math.max(sx,ex),Math.max(sy,ey),p);p.setStyle(Paint.Style.FILL);}
            if(px>=0){p.setColor(Color.YELLOW);c.drawCircle((float)(ox+px*image.getWidth()*scale),(float)(oy+py*image.getHeight()*scale),Ui.dp(TeachActivity.this,5),p);}
        }
        private float clampX(float x){return Math.max(ox,Math.min(ox+image.getWidth()*scale,x));}
        private float clampY(float y){return Math.max(oy,Math.min(oy+image.getHeight()*scale,y));}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){getParent().requestDisallowInterceptTouchEvent(true);
            if(pointMode){if(e.getAction()==MotionEvent.ACTION_UP){px=(clampX(e.getX())-ox)/(image.getWidth()*scale);py=(clampY(e.getY())-oy)/(image.getHeight()*scale);invalidate();}return true;}
            if(e.getAction()==MotionEvent.ACTION_DOWN){sx=ex=clampX(e.getX());sy=ey=clampY(e.getY());selected=true;}
            if(e.getAction()==MotionEvent.ACTION_MOVE||e.getAction()==MotionEvent.ACTION_UP){ex=clampX(e.getX());ey=clampY(e.getY());}
            invalidate();return true;
        }
        JSONObject region(){if(!selected||scale<=0)return null;return Vision.rect((Math.min(sx,ex)-ox)/(image.getWidth()*scale),(Math.min(sy,ey)-oy)/(image.getHeight()*scale),(Math.max(sx,ex)-ox)/(image.getWidth()*scale),(Math.max(sy,ey)-oy)/(image.getHeight()*scale));}
    }
}
