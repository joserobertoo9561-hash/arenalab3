package br.com.arenalab;

import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;

/** Dependency-free client for OpenAI Responses API with web search and allow-listed app actions. */
public final class AiClient {
    private static final String ENDPOINT="https://api.openai.com/v1/responses";
    public static final class ToolCall {
        public final String action,argument,style;
        ToolCall(String action,String argument,String style){this.action=action==null?"":action;this.argument=argument==null?"":argument;this.style=style==null?"":style;}
    }
    public static final class Result {
        public final String text;public final List<String> sources;public final List<ToolCall> tools;
        Result(String text,List<String> sources,List<ToolCall> tools){this.text=text;this.sources=sources;this.tools=tools;}
        public String display(){StringBuilder b=new StringBuilder(text==null?"":text.trim());if(!sources.isEmpty()){if(b.length()>0)b.append("\n\n");b.append("Fontes:\n");int n=0;for(String u:sources){if(n++>=6)break;b.append("• ").append(u).append("\n");}return b.toString().trim();}return b.toString();}
    }
    public Result ask(String key,String model,String prompt,String context,boolean web) throws Exception {
        if(key==null||key.trim().isEmpty())throw new IllegalStateException("Chave de API não configurada");if(model==null||model.trim().isEmpty())model="gpt-6-astra";
        HttpURLConnection c=(HttpURLConnection)new URL(ENDPOINT).openConnection();c.setRequestMethod("POST");c.setDoOutput(true);c.setConnectTimeout(20000);c.setReadTimeout(web?70000:45000);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Authorization","Bearer "+key.trim());c.setRequestProperty("User-Agent","ArenaLab/0.3");
        JSONObject body=new JSONObject();body.put("model",model.trim());body.put("max_output_tokens",1400);body.put("store",false);JSONObject reasoning=new JSONObject();reasoning.put("effort","high");body.put("reasoning",reasoning);
        body.put("instructions","Você é Arena AI, agente de um laboratório pessoal de Clash Royale. Seja direto, útil e explique incertezas. Nunca invente algo que o estado local não forneceu. Para controlar o app, use exclusivamente arena_action. Nunca forneça coordenadas de toque, nunca compre nada e nunca mande melhorar carta/gastar ouro. O motor Android local valida cada gesto. Em pesquisa de meta, priorize dados recentes e cite fontes. "+(context==null?"":context));body.put("input",prompt==null?"":prompt);
        JSONArray tools=new JSONArray();
        if(web){JSONObject t=new JSONObject();t.put("type","web_search");t.put("search_context_size","medium");tools.put(t);}
        tools.put(actionTool());body.put("tools",tools);body.put("tool_choice","auto");
        byte[] data=body.toString().getBytes("UTF-8");c.setFixedLengthStreamingMode(data.length);try(OutputStream out=c.getOutputStream()){out.write(data);}int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();String raw=read(in);JSONObject json=new JSONObject(raw.isEmpty()?"{}":raw);
        if(code<200||code>=300){JSONObject e=json.optJSONObject("error");throw new IOException(e==null?"HTTP "+code:e.optString("message","HTTP "+code));}
        StringBuilder text=new StringBuilder();LinkedHashSet<String> sources=new LinkedHashSet<>();List<ToolCall> calls=new ArrayList<>();JSONArray output=json.optJSONArray("output");
        if(output!=null)for(int i=0;i<output.length();i++){JSONObject item=output.optJSONObject(i);if(item==null)continue;String type=item.optString("type");
            if("function_call".equals(type)&&"arena_action".equals(item.optString("name"))){try{JSONObject a=new JSONObject(item.optString("arguments","{}"));calls.add(new ToolCall(a.optString("action"),a.optString("argument"),a.optString("style")));}catch(Exception ignored){}continue;}
            if(!"message".equals(type))continue;JSONArray content=item.optJSONArray("content");if(content==null)continue;for(int j=0;j<content.length();j++){JSONObject part=content.optJSONObject(j);if(part==null)continue;if("output_text".equals(part.optString("type"))){if(text.length()>0)text.append("\n");text.append(part.optString("text"));JSONArray ann=part.optJSONArray("annotations");if(ann!=null)for(int k=0;k<ann.length();k++){JSONObject a=ann.optJSONObject(k);if(a!=null&&a.optString("url").startsWith("http"))sources.add(a.optString("url"));}}else if("refusal".equals(part.optString("type"))){text.append(part.optString("refusal"));}}
        }
        if(text.length()==0&&calls.isEmpty())text.append("A API respondeu sem texto ou ação utilizável.");return new Result(text.toString().trim(),new ArrayList<>(sources),calls);
    }
    private static JSONObject actionTool() throws JSONException {
        JSONObject tool=new JSONObject();tool.put("type","function");tool.put("name","arena_action");tool.put("description","Executa somente ações de alto nível permitidas pelo Arena Lab quando o usuário pedir. Não aceita coordenadas, compras ou melhorias.");
        JSONObject schema=new JSONObject();schema.put("type","object");JSONObject props=new JSONObject();
        JSONObject action=new JSONObject();action.put("type","string");JSONArray values=new JSONArray();String[] names={"status","explain","set_style","start_auto","start_observe","pause","stop","open_clash","youtube","browser","spotify"};for(String n:names)values.put(n);action.put("enum",values);action.put("description","Ação permitida.");props.put("action",action);
        JSONObject arg=new JSONObject();arg.put("type","string");arg.put("description","Busca, música ou texto opcional para a ação.");props.put("argument",arg);
        JSONObject style=new JSONObject();style.put("type","string");JSONArray styles=new JSONArray();styles.put("balanced");styles.put("defensive");styles.put("aggressive");style.put("enum",styles);style.put("description","Usado apenas por set_style.");props.put("style",style);
        schema.put("properties",props);JSONArray req=new JSONArray();req.put("action");schema.put("required",req);schema.put("additionalProperties",false);tool.put("parameters",schema);return tool;
    }
    private static String read(InputStream in) throws IOException {if(in==null)return "";ByteArrayOutputStream out=new ByteArrayOutputStream();byte[]b=new byte[8192];for(int n;(n=in.read(b))!=-1;)out.write(b,0,n);in.close();return out.toString("UTF-8");}
}
