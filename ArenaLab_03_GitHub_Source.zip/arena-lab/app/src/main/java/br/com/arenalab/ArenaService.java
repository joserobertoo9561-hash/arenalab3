package br.com.arenalab;

import android.accessibilityservice.*;
import android.app.KeyguardManager;
import android.content.*;
import android.graphics.*;
import android.hardware.HardwareBuffer;
import android.os.*;
import android.view.*;
import android.view.accessibility.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

/** Local accessibility pilot. Gestures are gated to Clash Royale foreground only. */
public final class ArenaService extends AccessibilityService {
    public static final String TARGET="com.supercell.clashroyale";
    public static ArenaService instance;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService screenshots=Executors.newSingleThreadExecutor();
    private final ExecutorService brains=Executors.newSingleThreadExecutor(),research=Executors.newSingleThreadExecutor();
    private Store store;private boolean running,paused,execute,capturing,seenGame,inBattle,autonomy,aiBusy;
    private long generation,started,ends,lastAction,battleStarted,externalUntil,foreignSince,lastAi,lastAiState;
    private int rounds,spent,startingGold=-1,homeFrames,resultFrames,unknownFrames,style=Core.STYLE_BALANCED,previousLane;
    private final String[] handCandidate={"","","",""},handStable={"","","",""};private final int[] handVotes=new int[4];
    private double smoothedLeftThreat,smoothedRightThreat,threatPersistence,recentSpend;
    private String lastScene="",lastStatus="",lastPlayedCard="";
    private LinearLayout panel;private TextView panelStatus;private WindowManager wm;
    private JSONObject conf=new JSONObject(),layout;private JSONArray templates=new JSONArray();private List<Core.Card> deck=new ArrayList<>();
    private final Set<String> upgraded=new HashSet<>();private final ArrayDeque<String> equipQueue=new ArrayDeque<>();
    private Macro macro;private BroadcastReceiver screenOff;private Memory memory;private final AutonomyClient autonomyClient=new AutonomyClient();private String autoPhase="boot";
    private final Runnable tick=new Runnable(){@Override public void run(){
        if(!running||paused)return;long now=SystemClock.elapsedRealtime();
        if(now>ends){stopSession("Limite de tempo atingido",false);return;}
        if(now-started>25000&&!seenGame&&externalUntil<now){stopSession("Clash não apareceu em primeiro plano",false);return;}
        capture(false);
    }};
    private static final class Macro {String name;JSONArray steps;int index,retries,stable;Runnable done;Macro(String n,JSONArray s,Runnable d){name=n;steps=s;done=d;}}

    @Override protected void onServiceConnected(){super.onServiceConnected();instance=this;store=new Store(this);wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        screenOff=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){stopSession("Tela desligada",true);}};
        if(Build.VERSION.SDK_INT>=33)registerReceiver(screenOff,new IntentFilter(Intent.ACTION_SCREEN_OFF),Context.RECEIVER_NOT_EXPORTED);else registerReceiver(screenOff,new IntentFilter(Intent.ACTION_SCREEN_OFF));
        memory=new Memory(this);store.runtime("Serviço conectado · piloto parado");store.log("Serviço 0.4 conectado; nenhuma sessão iniciada automaticamente.");
    }
    public static String readiness(Store s){
        JSONObject c=s.load();if(c.optBoolean("fullAutonomy"))return "";
        StringBuilder issues=new StringBuilder();JSONObject layout=c.optJSONObject("layout");
        if(s.deck().size()!=8)issues.append("• Monte um deck de 8 cartas.\n");
        String[] keys={"arena","hand0","hand1","hand2","hand3","elixir"};for(String k:keys)if(layout==null||!Vision.validRect(layout.optJSONObject(k)))issues.append("• Ensine a área: ").append(k).append(".\n");
        Set<String> scenes=new HashSet<>(),cards=new HashSet<>();JSONArray examples=s.templates();
        for(int i=0;i<examples.length();i++){JSONObject t=examples.optJSONObject(i);if(t==null)continue;if("scene".equals(t.optString("kind")))scenes.add(t.optString("label"));if("card".equals(t.optString("kind")))cards.add(t.optString("label"));}
        for(String name:new String[]{"home","battle","victory","loss"})if(!scenes.contains(name))issues.append("• Ensine a tela: ").append(name).append(".\n");
        for(Core.Card card:s.deck())if(!cards.contains(card.id))issues.append("• Ensine a ilustração: ").append(card.name).append(".\n");
        if(!c.optBoolean("deckApplied")&&!c.optBoolean("autoDeck"))issues.append("• Equipe o deck no jogo e registre isso em Avançado > Deck.\n");
        if(!validProcedure(s.procedure("battle.start")))issues.append("• Ensine Iniciar partida, terminando com verificação.\n");
        if(!validProcedure(s.procedure("result.dismiss")))issues.append("• Ensine Sair do resultado, terminando com verificação.\n");
        if(c.optBoolean("autoDeck")&&!c.optBoolean("deckApplied")){int slot=0;for(Core.Card card:s.deck()){if(!validProcedure(s.procedure("equip."+card.id+"."+slot)))issues.append("• Ensine Equipar ").append(card.name).append(" no slot ").append(slot+1).append(".\n");slot++;}}
        return issues.toString().trim();
    }
    private static boolean validProcedure(JSONArray a){
        if(a==null||a.length()<2)return false;JSONObject last=a.optJSONObject(a.length()-1);if(last==null||!last.optBoolean("verify"))return false;
        for(int i=0;i<a.length();i++){JSONObject s=a.optJSONObject(i);if(s==null||!Vision.validRect(s.optJSONObject("region"))||s.optJSONArray("feature")==null||s.optJSONArray("feature").length()!=Vision.SIDE*Vision.SIDE*3)return false;if(s.optBoolean("verify")&&i!=a.length()-1)return false;if(!s.optBoolean("verify")&&!Core.safePoint(s.optDouble("x",-1),s.optDouble("y",-1)))return false;}
        return true;
    }
    private void refreshCache(){conf=store.load();layout=conf.optJSONObject("layout");templates=conf.optJSONArray("templates");if(templates==null)templates=new JSONArray();deck=store.deck();style=store.style();}
    public void startSession(boolean act){
        stopSession("Sessão reiniciada",false);refreshCache();autonomy=act&&conf.optBoolean("fullAutonomy");
        if(act&&!autonomy){String issue=readiness(store);if(!issue.isEmpty()){status("Calibração incompleta");return;}}
        if(autonomy&&!new Secrets(this).hasApiKey()){status("Autonomia total precisa da chave de API");return;}
        running=true;paused=false;execute=act;generation++;started=SystemClock.elapsedRealtime();ends=started+Math.max(1,Math.min(180,conf.optInt("minutes",30)))*60000L;
        seenGame=false;inBattle=false;foreignSince=0;rounds=spent=homeFrames=resultFrames=unknownFrames=0;startingGold=-1;lastScene="";lastAction=0;externalUntil=0;previousLane=0;recentSpend=0;lastPlayedCard="";smoothedLeftThreat=smoothedRightThreat=threatPersistence=0;upgraded.clear();equipQueue.clear();macro=null;aiBusy=false;lastAi=lastAiState=0;
        autoPhase=conf.optString("autoPhase","");if(autonomy&&(autoPhase.isEmpty()||"boot".equals(autoPhase)))autoPhase=needsInventoryScan()?"inventory":"deck";
        Arrays.fill(handCandidate,"");Arrays.fill(handStable,"");Arrays.fill(handVotes,0);
        showPanel();status(autonomy?"Autonomia total · abrindo Clash":(act?"Piloto · aguardando Clash":"Observar · aguardando Clash"));
        if(autonomy){maybeRefreshCatalog();maybeResearch();launchTarget();}
        main.postDelayed(tick,500);
    }
    public void pauseSession(String reason){if(!running)return;paused=true;main.removeCallbacks(tick);status("Pausado · "+reason);}
    public void resumeSession(){if(!running||!paused)return;paused=false;status(execute?"Piloto retomado":"Observação retomada");main.post(tick);}
    public void stopSession(String reason,boolean remove){
        boolean wasRunning=running;running=false;paused=false;generation++;execute=false;macro=null;equipQueue.clear();externalUntil=0;main.removeCallbacks(tick);
        if(wasRunning&&store!=null)store.log(reason);if(store!=null)store.runtime("Parado · "+reason);if(panelStatus!=null)panelStatus.setText("Parado · "+reason);
        if(remove&&panel!=null){try{wm.removeView(panel);}catch(Exception ignored){}panel=null;panelStatus=null;}
    }
    public void setStyle(int value){style=Math.max(Core.STYLE_BALANCED,Math.min(Core.STYLE_AGGRESSIVE,value));store.setStyle(style);status("Estilo "+Core.styleName(style));}
    public void setStrategy(String mode){String id=Core.policy(mode).id;setStyle("defensive".equals(id)?Core.STYLE_DEFENSIVE:"aggressive".equals(id)?Core.STYLE_AGGRESSIVE:Core.STYLE_BALANCED);}
    public boolean suspendForAssistant(){if(!running||paused)return false;pauseSession("conversa com Arena AI");return true;}
    public void resumeAfterAssistant(){if(running&&paused)resumeSession();}
    public void suspendForExternal(String reason){if(!running)return;externalUntil=SystemClock.elapsedRealtime()+5*60000L;status("Suspenso · "+reason+" · volte ao Clash");}
    public String liveStatus(){return (running?(paused?"Pausado":"Ativo")+" · "+(execute?"piloto":"observar"):"Parado")+" · estilo "+Core.styleName(style)+" · "+rounds+" partida(s) · "+store.runtime();}
    public String snapshot(){return liveStatus()+" · cena "+(lastScene.isEmpty()?"desconhecida":lastScene)+" · decisão: "+store.decision();}
    public String explainLastDecision(){return store.decision();}
    @Override public void onAccessibilityEvent(AccessibilityEvent e){
        if(!running||e.getEventType()!=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED)return;CharSequence p=e.getPackageName();if(p==null)return;String pkg=p.toString();
        if(TARGET.equals(pkg)){foreignSince=0;if(externalUntil>0){externalUntil=0;status("Clash retomado");}return;}
        if(getPackageName().equals(pkg)||SystemClock.elapsedRealtime()<externalUntil)return;
        if(!seenGame)return;
        final long epoch=generation;status("Mudança de janela · verificando");
        main.postDelayed(()->{
            if(!running||paused||epoch!=generation)return;
            if(targetForeground()||targetVisible()){foreignSince=0;status(execute?"Piloto · Clash ativo":"Observar · Clash ativo");return;}
            if(foreignSince==0)foreignSince=SystemClock.elapsedRealtime();
        },900);
    }
    @Override public void onInterrupt(){stopSession("Serviço interrompido",true);}
    @Override public void onDestroy(){stopSession("Serviço desconectado",true);if(screenOff!=null)try{unregisterReceiver(screenOff);}catch(Exception ignored){}screenshots.shutdownNow();brains.shutdownNow();research.shutdownNow();instance=null;super.onDestroy();}
    private String foregroundPackage(){AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)return "";CharSequence p=root.getPackageName();return p==null?"":p.toString();}
    private boolean targetForeground(){
        PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);KeyguardManager km=(KeyguardManager)getSystemService(KEYGUARD_SERVICE);if(!pm.isInteractive()||km.isKeyguardLocked())return false;return TARGET.equals(foregroundPackage());
    }
    private boolean targetVisible(){
        try{for(AccessibilityWindowInfo w:getWindows()){AccessibilityNodeInfo r=w.getRoot();if(r==null)continue;CharSequence p=r.getPackageName();if(p!=null&&TARGET.contentEquals(p))return true;}}catch(Exception ignored){}return false;
    }
    public void showPanel(){
        if(panel!=null){panel.setVisibility(View.VISIBLE);return;}if(wm==null)return;
        panel=Ui.column(this);panel.setPadding(Ui.dp(this,8),Ui.dp(this,4),Ui.dp(this,8),Ui.dp(this,5));panel.setBackground(Ui.shape(Ui.PANEL,Ui.dp(this,14)));
        panelStatus=Ui.text(this,"Arena · parado",10,Ui.ACCENT);panel.addView(panelStatus);LinearLayout row=new LinearLayout(this);panel.addView(row);
        String[] labels={"⏯","IA","◎","✕"};
        for(int i=0;i<labels.length;i++){final int index=i;Button b=new Button(this);b.setText(labels[i]);b.setTextSize(index==1?10:15);b.setAllCaps(false);b.setTextColor(Ui.TEXT);b.setMinWidth(0);b.setPadding(0,0,0,0);row.addView(b,new LinearLayout.LayoutParams(Ui.dp(this,index==1?54:42),Ui.dp(this,36)));b.setOnClickListener(v->{
            if(index==0){if(!running)return;if(paused)resumeSession();else pauseSession("painel");}
            else if(index==1){Intent a=new Intent(this,AgentActivity.class);a.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(a);}
            else if(index==2)teach();else stopSession("Painel fechado",true);
        });}
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(-2,-2,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);lp.gravity=Gravity.TOP|Gravity.START;lp.x=Ui.dp(this,4);lp.y=Ui.dp(this,72);wm.addView(panel,lp);
    }
    private void status(String s){if(panelStatus!=null)panelStatus.setText(s);if(store!=null)store.runtime(s);if(!s.equals(lastStatus)){if(store!=null)store.log(s);lastStatus=s;}}
    private void teach(){
        if(!targetForeground()){status("Abra o Clash para capturar");return;}boolean wasRunning=running;boolean wasPaused=paused;running=false;paused=false;generation++;main.removeCallbacks(tick);if(wasRunning)store.log("Captura de ensino; sessão interrompida.");
        if(capturing){status("Aguarde a captura em andamento");return;}if(panel!=null)panel.setVisibility(View.INVISIBLE);main.postDelayed(()->capture(true),180);
    }
    private void capture(boolean teach){
        if(capturing){if(running&&!paused)main.postDelayed(tick,500);return;}
        if(!targetForeground()){
            String pkg=foregroundPackage();long now=SystemClock.elapsedRealtime();
            if(teach){showPanel();status("Captura cancelada: abra o Clash");}
            else if(getPackageName().equals(pkg)||now<externalUntil){foreignSince=0;status("Suspenso · volte ao Clash");if(running&&!paused)main.postDelayed(tick,900);}
            else if(targetVisible()){foreignSince=0;status("Clash visível · aguardando foco");if(running&&!paused)main.postDelayed(tick,700);}
            else if(seenGame){if(foreignSince==0)foreignSince=now;if(now-foreignSince<3000){status("Outro app detectado · verificando");if(running&&!paused)main.postDelayed(tick,700);}else stopSession("Clash saiu de primeiro plano",false);}
            else if(running&&!paused)main.postDelayed(tick,900);return;
        }
        foreignSince=0;if(!teach){seenGame=true;if(externalUntil>0)externalUntil=0;}capturing=true;final long epoch=generation;
        takeScreenshot(Display.DEFAULT_DISPLAY,screenshots,new TakeScreenshotCallback(){
            @Override public void onSuccess(ScreenshotResult result){
                HardwareBuffer buffer=result.getHardwareBuffer();Bitmap wrapped=null,copy=null;try{wrapped=Bitmap.wrapHardwareBuffer(buffer,result.getColorSpace());if(wrapped!=null)copy=wrapped.copy(Bitmap.Config.ARGB_8888,false);}catch(Exception ignored){}finally{if(wrapped!=null)wrapped.recycle();buffer.close();}
                final Bitmap bitmap=copy;main.post(()->{
                    capturing=false;if(bitmap==null){captureFailure(teach,epoch);return;}try{if(epoch!=generation||!targetForeground())return;
                        if(teach){File f=new File(getCacheDir(),"teach.png");try(FileOutputStream out=new FileOutputStream(f)){bitmap.compress(Bitmap.CompressFormat.PNG,100,out);}if(panel!=null)panel.setVisibility(View.INVISIBLE);Intent i=new Intent(ArenaService.this,TeachActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}
                        else if(running&&!paused)process(bitmap,epoch);
                    }catch(Exception e){stopSession("Erro de leitura: "+e.getClass().getSimpleName(),false);}finally{bitmap.recycle();if(running&&!paused&&epoch==generation)main.postDelayed(tick,inBattle?430:720);}
                });
            }
            @Override public void onFailure(int error){main.post(()->{capturing=false;captureFailure(teach,epoch);});}
        });
    }
    private void captureFailure(boolean teach,long epoch){if(epoch!=generation)return;if(teach){showPanel();status("Captura indisponível no aparelho");}else stopSession("Android recusou a captura",false);}
    private void process(Bitmap image,long epoch){
        double threshold=conf.optInt("threshold",92)/100.;if(image.getWidth()>=image.getHeight()){stopSession("Use o telefone em retrato",false);return;}if(macro!=null&&!autonomy){processMacro(image,epoch);return;}
        Vision.Match match=Vision.scene(image,templates);
        if(autonomy){
            if(memory!=null)memory.frame(image,lastScene.isEmpty()?"auto":lastScene);long now=SystemClock.elapsedRealtime();
            boolean recentBattle=inBattle&&now-lastAiState<3600&&localBattleReady();
            if(recentBattle){match.label="battle";match.confidence=Math.max(match.confidence,.97);match.margin=.50;if(now-lastAi>2600)requestAutonomy(image,epoch);}
            else{if(now-lastAi>1050)requestAutonomy(image,epoch);else status("Autonomia · aguardando leitura visual");return;}
        }
        if(match.confidence<threshold||match.margin<.025){status("Tela desconhecida · "+Math.round(match.confidence*100)+"% · use ◎");if(execute&&++unknownFrames>=18)stopSession("Tela não reconhecida; ensine outro exemplo",false);return;}
        unknownFrames=0;String scene=match.label;if(!scene.equals(lastScene)){homeFrames=resultFrames=0;lastScene=scene;}
        if("battle".equals(scene)){
            homeFrames=resultFrames=0;if(!inBattle){inBattle=true;battleStarted=SystemClock.elapsedRealtime();store.log("Partida reconhecida.");}
            Core.State s=new Core.State();s.battle=true;s.confidence=match.confidence;s.style=style;s.previousLane=previousLane;s.recentLane=previousLane;s.lastPlayedCard=lastPlayedCard;s.battleSeconds=Math.max(0,(SystemClock.elapsedRealtime()-battleStarted)/1000.);recentSpend*=.955;s.recentSpend=recentSpend;
            s.geometryValid=layout!=null&&Core.sameAspect((double)image.getWidth()/image.getHeight(),layout.optDouble("aspect"));if(!s.geometryValid){status("Ensine as áreas desta resolução");if(execute)stopSession("Geometria incompatível",false);return;}
            s.elixir=Vision.elixir(image,layout.optJSONObject("elixir"));Vision.threats(image,layout.optJSONObject("arena"),s);s.battleSeconds=(SystemClock.elapsedRealtime()-battleStarted)/1000.;s.recentLane=previousLane;s.lastPlayedCard=lastPlayedCard;
            smoothedLeftThreat=smoothedLeftThreat*.64+s.leftThreat*.36;smoothedRightThreat=smoothedRightThreat*.64+s.rightThreat*.36;double rawThreat=Math.max(s.leftThreat,s.rightThreat);
            threatPersistence=rawThreat>.0014?Math.min(1,threatPersistence+.24):Math.max(0,threatPersistence-.17);s.leftThreat=smoothedLeftThreat;s.rightThreat=smoothedRightThreat;s.threatPersistence=threatPersistence;s.secondsSinceAction=lastAction==0?99:(SystemClock.elapsedRealtime()-lastAction)/1000.;
            for(int i=0;i<4;i++){JSONObject r=layout.optJSONObject("hand"+i);if(!Vision.validRect(r))continue;Vision.Match cm=Vision.card(image,r,templates);
                if(cm.margin>=.02&&cm.confidence>=threshold){if(cm.label.equals(handCandidate[i]))handVotes[i]++;else{handCandidate[i]=cm.label;handVotes[i]=1;}if(handVotes[i]>=2)handStable[i]=cm.label;}else handVotes[i]=Math.max(0,handVotes[i]-1);
                s.hand[i]=Core.byId(deck,handStable[i]);s.cardConfidence[i]=s.hand[i]!=null&&handStable[i].equals(cm.label)?cm.confidence:0;}
            Core.Action action=Core.choose(s,threshold);String actionText=action==null?"aguardar":(s.hand[action.slot]==null?"ação":s.hand[action.slot].name)+" ["+String.format(Locale.ROOT,"%.1f",action.score)+"]";
            status((execute?"Piloto":"Observar")+" · E≈"+(int)s.elixir+" · ameaça "+Math.round(Math.max(s.leftThreat,s.rightThreat)*1000)+" · "+actionText);
            if(action!=null&&s.hand[action.slot]!=null)store.decision("Planejei "+s.hand[action.slot].name+" porque "+action.reason+". Ameaça E/D="+Math.round(s.leftThreat*1000)+"/"+Math.round(s.rightThreat*1000)+", elixir≈"+(int)s.elixir+".");
            if(execute&&action!=null&&SystemClock.elapsedRealtime()-lastAction>900)play(image,layout,action,epoch);
        }else if("victory".equals(scene)||"loss".equals(scene)){
            if(++resultFrames<2)return;if(inBattle&&SystemClock.elapsedRealtime()-battleStarted>3000){rounds++;store.recordResult("victory".equals(scene));inBattle=false;smoothedLeftThreat=smoothedRightThreat=threatPersistence=recentSpend=0;lastPlayedCard="";store.log("Resultado reconhecido: "+scene+"; partidas na sessão: "+rounds);}
            status("Resultado · "+scene);if(execute&&rounds>=conf.optInt("roundLimit",5)){stopSession("Limite de partidas atingido",false);return;}if(execute&&SystemClock.elapsedRealtime()-lastAction>1300)beginMacro("result.dismiss",()->{});
        }else if("home".equals(scene)){
            status((execute?"Piloto":"Observar")+" · início · "+rounds+" partidas");if(inBattle){stopSession("Partida voltou ao início sem resultado reconhecido",false);return;}if(!execute||++homeFrames<2||SystemClock.elapsedRealtime()-lastAction<1200)return;
            if(conf.optBoolean("autoDeck")&&!conf.optBoolean("deckApplied")){equipDeck();return;}if(!conf.optBoolean("deckApplied")){stopSession("Deck não registrado como equipado",false);return;}
            if(conf.optBoolean("autoUpgrade")){Core.Card next=Core.nextUpgrade(deck,conf.optInt("gold"),Math.max(0,conf.optInt("goldBudget")-spent),upgraded);if(next!=null){String name="upgrade."+next.id;if(validProcedure(store.procedure(name))){beginMacro(name,()->{spent+=next.gold;upgraded.add(next.id);JSONObject o=store.load();Store.put(o,"gold",Math.max(0,o.optInt("gold")-next.gold));store.save(o);next.level++;next.ready=false;next.gold=0;store.saveCard(next);refreshCache();store.log("Melhoria verificada: "+next.name+".");});return;}upgraded.add(next.id);store.log("Melhoria sem procedimento: "+next.name+"; ignorada.");return;}}
            beginMacro("battle.start",()->{lastScene="";});
        }
    }
    private void equipDeck(){if(equipQueue.isEmpty()){int i=0;for(Core.Card c:deck){String name="equip."+c.id+"."+i++;if(!validProcedure(store.procedure(name))){stopSession("Falta procedimento de equipar "+c.name,false);return;}equipQueue.add(name);}}equipNext();}
    private void equipNext(){if(!running||paused||!execute)return;if(equipQueue.isEmpty()){JSONObject c=store.load();Store.put(c,"deckApplied",true);store.save(c);conf=c;status("Deck equipado automaticamente");return;}beginMacro(equipQueue.removeFirst(),()->equipNext());}
    private void beginMacro(String name,Runnable after){if(!running||paused||!execute||!targetForeground())return;JSONArray steps=store.procedure(name);if(!validProcedure(steps)){stopSession("Procedimento incompleto: "+name,false);return;}macro=new Macro(name,steps,after);status("Automação · "+name);lastAction=SystemClock.elapsedRealtime();}
    private void processMacro(Bitmap image,long epoch){
        Macro run=macro;if(run==null||!execute||!running||paused)return;JSONObject step=run.steps.optJSONObject(run.index);if(!Core.sameAspect((double)image.getWidth()/image.getHeight(),step.optDouble("aspect"))){stopSession("Resolução mudou no procedimento",false);return;}
        double score=Vision.similarity(Vision.feature(image,step.optJSONObject("region")),step.optJSONArray("feature"));if(score<.94){run.stable=0;status("Conferindo "+run.name+" · "+Math.round(score*100)+"%");if(++run.retries>=14)stopSession("Passo não conferiu; sequência interrompida",false);return;}
        if(++run.stable<2)return;run.stable=run.retries=0;if(step.optBoolean("verify")){macro=null;lastAction=SystemClock.elapsedRealtime();store.log("Procedimento verificado: "+run.name);run.done.run();return;}final int stepIndex=run.index;tap(step.optDouble("x"),step.optDouble("y"),image.getWidth(),image.getHeight(),epoch,()->{if(macro==run&&run.index==stepIndex){run.index++;lastAction=SystemClock.elapsedRealtime();}});
    }
    private void play(Bitmap image,JSONObject layout,Core.Action action,long epoch){
        JSONObject card=layout.optJSONObject("hand"+action.slot),arena=layout.optJSONObject("arena");if(card==null||arena==null)return;double sx=(card.optDouble("l")+card.optDouble("r"))*.5,sy=(card.optDouble("t")+card.optDouble("b"))*.5;double dx=arena.optDouble("l")+(arena.optDouble("r")-arena.optDouble("l"))*action.x;double dy=arena.optDouble("t")+(arena.optDouble("b")-arena.optDouble("t"))*action.y;if(!Core.safePoint(sx,sy)||!Core.safePoint(dx,dy))return;
        lastAction=SystemClock.elapsedRealtime();previousLane=action.x<.5?-1:1;final int width=image.getWidth(),height=image.getHeight();
        tap(sx,sy,width,height,epoch,()->main.postDelayed(()->tap(dx,dy,width,height,epoch,()->{recentSpend=Math.min(20,recentSpend+Math.max(1,action.elixir));lastPlayedCard=action.cardId;store.log("Carta colocada: slot "+(action.slot+1)+"; "+action.reason);JSONObject ev=new JSONObject();Store.put(ev,"type","play");Store.put(ev,"card",action.cardId);Store.put(ev,"elixir",action.elixir);Store.put(ev,"lane",previousLane);Store.put(ev,"score",action.score);Store.put(ev,"reason",action.reason);store.telemetry(ev);}),145));
    }
    private boolean needsInventoryScan(){JSONObject c=store.load();return c.optLong("inventoryScannedAt",0)<System.currentTimeMillis()-24L*60*60*1000||ownedCount()<8;}
    private int ownedCount(){int n=0;for(Core.Card c:store.cards())if(c.owned)n++;return n;}
    private boolean localBattleReady(){if(deck.size()!=8||layout==null||!Vision.validRect(layout.optJSONObject("arena")))return false;int n=0;Set<String> ids=new HashSet<>();for(int i=0;i<templates.length();i++){JSONObject t=templates.optJSONObject(i);if(t!=null&&"card".equals(t.optString("kind")))ids.add(t.optString("label"));}for(Core.Card c:deck)if(ids.contains(c.id))n++;return n>=4;}
    private void savePhase(String phase){autoPhase=phase;JSONObject c=store.load();Store.put(c,"autoPhase",phase);store.save(c);conf=c;}
    private String goalText(){
        if("inventory".equals(autoPhase))return "Vá para a coleção e faça uma varredura sistemática. Leia nomes e níveis das cartas visíveis e role a coleção. Não abra loja. Marque inventory_complete somente depois de alcançar o fim e reconhecer que não há novas cartas.";
        if("deck".equals(autoPhase))return "Equipe exatamente o deck alvo informado no estado local. Navegue pelo editor de deck e faça um passo seguro por captura. Marque goal_done quando as 8 cartas alvo estiverem equipadas.";
        if("rewards".equals(autoPhase))return "Resgate apenas recompensas grátis e abra apenas baús que já estejam prontos/grátis. Nunca gaste gemas, dinheiro, chaves ou itens mágicos. Marque goal_done quando não houver recompensa grátis segura visível.";
        if("upgrades".equals(autoPhase))return "Melhore somente cartas do deck alvo usando OURO, dentro do orçamento restante. Nunca gemas, ofertas ou dinheiro. Em qualquer toque de melhoria informe kind=upgrade_gold e cost_gold exato. Marque goal_done quando não houver melhoria segura dentro do orçamento.";
        return "Comece ou continue partidas. Se estiver em batalha e o motor local ainda não tiver aprendido a mão, identifique as 4 cartas e escolha no máximo uma jogada segura. Após resultado, feche a tela e inicie a próxima partida.";
    }
    private String contextText(){JSONObject c=store.load();int budget=Math.max(0,c.optInt("goldBudget",0)-spent);return "fase="+autoPhase+"; deck_alvo=["+store.deckNames()+"]; cartas_possuidas="+ownedCount()+"; ouro="+c.optInt("gold",-1)+"; orçamento_ouro_restante="+budget+"; partidas="+rounds+"; estratégia="+Core.styleName(style)+"; memória="+store.memorySummary();}
    private void requestAutonomy(Bitmap image,long epoch){
        if(aiBusy||!running||paused||epoch!=generation)return;aiBusy=true;lastAi=SystemClock.elapsedRealtime();Bitmap copy=image.copy(Bitmap.Config.ARGB_8888,false);String goal=goalText(),ctx=contextText();String key=new Secrets(this).apiKey(),model=conf.optString("aiModel","gpt-6-astra");status("Autonomia · "+autoPhase+" · analisando");
        brains.execute(()->{try{AutonomyClient.Observation o=autonomyClient.analyze(key,model,copy,goal,ctx);main.post(()->{try{if(running&&!paused&&epoch==generation)applyAutonomy(o,copy,epoch);}finally{aiBusy=false;copy.recycle();}});}catch(Exception e){main.post(()->{aiBusy=false;copy.recycle();if(running&&epoch==generation)status("Autonomia visual falhou · "+e.getClass().getSimpleName());});}});
    }
    private void applyAutonomy(AutonomyClient.Observation o,Bitmap image,long epoch){
        lastAiState=SystemClock.elapsedRealtime();if(o.confidence<.35){status("Autonomia · baixa confiança · aguardando");return;}lastScene=o.scene;int changed=store.mergeObservedCards(o.cards);if(changed>0){refreshCache();if(memory!=null)memory.event("inventory","Atualizei "+changed+" carta(s) pela leitura visual.");}
        if(o.gold>=0){if(startingGold<0)startingGold=o.gold;if(startingGold>=o.gold)spent=Math.max(spent,startingGold-o.gold);JSONObject c=store.load();Store.put(c,"gold",o.gold);store.save(c);conf=c;}
        learnHand(image,o);if("battle".equals(o.scene)){if(!inBattle){inBattle=true;battleStarted=SystemClock.elapsedRealtime();store.log("Partida reconhecida pela visão autônoma.");}if(layout==null){layout=Vision.defaultLayout((double)image.getWidth()/image.getHeight());JSONObject c=store.load();Store.put(c,"layout",layout);store.save(c);conf=c;}}
        if(("victory".equals(o.scene)||"loss".equals(o.scene)||"win".equals(o.result)||"loss".equals(o.result))&&inBattle){boolean win="victory".equals(o.scene)||"win".equals(o.result);rounds++;store.recordResult(win);inBattle=false;store.log("Resultado autônomo: "+(win?"vitória":"derrota")+"; partidas="+rounds);if(memory!=null)memory.event("result",win?"vitória":"derrota");savePhase("match");}
        if("inventory".equals(autoPhase)&&o.inventoryComplete){if(ownedCount()<8){status("Coleção ainda incompleta · continuando leitura");return;}JSONObject c=store.load();Store.put(c,"inventoryScannedAt",System.currentTimeMillis());Store.put(c,"metaUpdatedAt",0);store.save(c);List<Core.Card>d=Core.buildDeck(store.cards());if(d.size()==8)store.saveDeck(d);refreshCache();savePhase("deck");maybeResearch();status("Coleção lida · deck calculado");return;}
        if("deck".equals(autoPhase)&&o.goalDone){JSONObject c=store.load();Store.put(c,"deckApplied",true);store.save(c);conf=c;savePhase(conf.optBoolean("autoRewards",true)?"rewards":(conf.optBoolean("autoUpgrade")?"upgrades":"match"));return;}
        if("rewards".equals(autoPhase)&&o.goalDone){savePhase(conf.optBoolean("autoUpgrade")?"upgrades":"match");return;}
        if("upgrades".equals(autoPhase)&&o.goalDone){savePhase("match");return;}
        status("Autonomia · "+o.scene+" · "+(o.reason.isEmpty()?o.action:o.reason));
        if(execute)executeAutoAction(o,image,epoch);
    }
    private void learnHand(Bitmap image,AutonomyClient.Observation o){
        if(!"battle".equals(o.scene)||o.hand==null||o.hand.length()==0)return;if(layout==null)layout=Vision.defaultLayout((double)image.getWidth()/image.getHeight());
        for(int i=0;i<o.hand.length();i++){JSONObject h=o.hand.optJSONObject(i);if(h==null)continue;int slot=h.optInt("slot",i);if(slot<0||slot>3)continue;Core.Card c=store.cardByName(h.optString("name"));if(c==null||hasCardTemplate(c.id))continue;JSONObject region=layout.optJSONObject("hand"+slot);if(!Vision.validRect(region))continue;JSONObject t=new JSONObject();Store.put(t,"kind","card");Store.put(t,"label",c.id);Store.put(t,"aspect",(double)image.getWidth()/image.getHeight());Store.put(t,"region",region);Store.put(t,"feature",Vision.encode(Vision.feature(image,region)));store.addTemplate(t);store.log("Aprendi automaticamente a aparência de "+c.name+".");}
        refreshCache();
    }
    private boolean hasCardTemplate(String id){for(int i=0;i<templates.length();i++){JSONObject t=templates.optJSONObject(i);if(t!=null&&"card".equals(t.optString("kind"))&&id.equals(t.optString("label")))return true;}return false;}
    private void executeAutoAction(AutonomyClient.Observation o,Bitmap image,long epoch){
        if(!o.safe||"none".equals(o.action)||!running||paused||epoch!=generation)return;String kind=o.kind==null?"":o.kind.toLowerCase(Locale.ROOT);String forbidden="shop offer buy purchase gem gems money realmoney key magic unlocknow";for(String bad:forbidden.split(" "))if(kind.contains(bad)){store.log("Ação bloqueada por segurança: "+kind);return;}
        if("play".equals(o.action)){
            if(!"battle".equals(o.scene)||localBattleReady()||o.slot<0||o.slot>3||!Core.safePoint(o.x,o.y)||o.y>.83)return;if(layout==null)layout=Vision.defaultLayout((double)image.getWidth()/image.getHeight());JSONObject r=layout.optJSONObject("hand"+o.slot);if(!Vision.validRect(r))return;double sx=(r.optDouble("l")+r.optDouble("r"))*.5,sy=(r.optDouble("t")+r.optDouble("b"))*.5;lastAction=SystemClock.elapsedRealtime();tap(sx,sy,image.getWidth(),image.getHeight(),epoch,()->main.postDelayed(()->tap(o.x,o.y,image.getWidth(),image.getHeight(),epoch,()->{if(memory!=null)memory.event("ai_play",o.reason);}),140));return;
        }
        Set<String> allowed=new HashSet<>(Arrays.asList("navigate","open_collection","scroll_collection","select_card","equip_card","open_deck","claim_free","open_free_chest","upgrade_gold","start_battle","dismiss","continue","close","back","next"));if(!allowed.contains(kind)){store.log("Ação semântica não permitida: "+kind);return;}
        if("upgrade_gold".equals(kind)){int remain=Math.max(0,conf.optInt("goldBudget",0)-spent);if(!"upgrades".equals(autoPhase)||o.costGold<=0||o.costGold>remain)return;}
        if("tap".equals(o.action)&&Core.safePoint(o.x,o.y)){lastAction=SystemClock.elapsedRealtime();tap(o.x,o.y,image.getWidth(),image.getHeight(),epoch,()->{if(memory!=null)memory.event("tap",kind+" · "+o.reason);});}
        else if("swipe".equals(o.action)&&Core.safePoint(o.x,o.y)&&Core.safePoint(o.x2,o.y2)){lastAction=SystemClock.elapsedRealtime();swipe(o.x,o.y,o.x2,o.y2,image.getWidth(),image.getHeight(),epoch);}
    }
    private void swipe(double x,double y,double x2,double y2,int width,int height,long epoch){if(!running||paused||!execute||epoch!=generation||!targetForeground())return;Path p=new Path();p.moveTo((float)(x*width),(float)(y*height));p.lineTo((float)(x2*width),(float)(y2*height));GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,360)).build();dispatchGesture(g,new GestureResultCallback(){@Override public void onCompleted(GestureDescription gesture){if(memory!=null)memory.event("swipe",autoPhase);}},main);}
    private void launchTarget(){try{Intent i=getPackageManager().getLaunchIntentForPackage(TARGET);if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}}catch(Exception ignored){}}
    private void maybeRefreshCatalog(){if(conf.optLong("catalogUpdatedAt",0)>System.currentTimeMillis()-24L*60*60*1000)return;CatalogSync.sync(this,(ok,msg)->{store.log(msg);refreshCache();});}
    private void maybeResearch(){if(!conf.optBoolean("autoResearch",true)||conf.optLong("metaUpdatedAt",0)>System.currentTimeMillis()-12L*60*60*1000)return;String key=new Secrets(this).apiKey();if(key.isEmpty())return;String model=conf.optString("aiModel","gpt-6-astra"),ctx=contextText();research.execute(()->{try{AiClient.Result r=new AiClient().ask(key,model,"Pesquise o meta atual de Clash Royale, tendências recentes de ladder, decks fortes e como jogar melhor com as cartas que eu possuo. Dê prioridade ao deck atual e a counters/rotações úteis.",ctx,true);store.saveMeta(r.text,r.sources);if(memory!=null)memory.event("research",r.text);store.log("Pesquisa autônoma de meta atualizada.");}catch(Exception e){store.log("Pesquisa autônoma falhou: "+e.getClass().getSimpleName());}});}

    private void tap(double x,double y,int width,int height,long epoch,Runnable done){
        if(!running||paused||!execute||epoch!=generation||!targetForeground()||!Core.safePoint(x,y))return;Path path=new Path();path.moveTo((float)(x*width),(float)(y*height));GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,0,65)).build();boolean sent=dispatchGesture(g,new GestureResultCallback(){@Override public void onCompleted(GestureDescription gesture){if(running&&!paused&&execute&&epoch==generation&&targetForeground())done.run();}@Override public void onCancelled(GestureDescription gesture){if(epoch==generation)stopSession("Android cancelou o gesto",false);}},main);if(!sent)stopSession("Android recusou o gesto",false);
    }
}
