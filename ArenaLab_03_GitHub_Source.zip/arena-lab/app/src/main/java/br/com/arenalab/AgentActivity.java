package br.com.arenalab;

import android.app.*;
import android.content.*;
import android.graphics.Typeface;
import android.os.*;
import android.text.util.Linkify;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.*;
import java.util.concurrent.*;

/** Local controls first; optional connected AI handles free-form reasoning and fresh web research. */
public final class AgentActivity extends Activity {
    private Store store;private Secrets secrets;private LinearLayout history;private EditText input;private ScrollView scroll;
    private final ExecutorService network=Executors.newSingleThreadExecutor();private final Handler main=new Handler(Looper.getMainLooper());
    private boolean resumeOnExit,externalLaunched,launchedGame;

    @Override public void onCreate(Bundle b){super.onCreate(b);store=new Store(this);secrets=new Secrets(this);ArenaService s=ArenaService.instance;resumeOnExit=s!=null&&s.suspendForAssistant();build();
        say("Arena AI","Fala comigo. Eu controlo o piloto local, explico o que ele está fazendo e, se a IA conectada estiver configurada, consigo conversar e pesquisar o meta recente sem sair do app.",false);
        String prompt=getIntent().getStringExtra("prompt");if(prompt!=null&&!prompt.trim().isEmpty())main.postDelayed(()->{say("Você",prompt,true);handle(prompt);},180);
    }
    private void build(){
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);LinearLayout root=Ui.column(this);root.setPadding(Ui.dp(this,16),Ui.dp(this,18),Ui.dp(this,16),Ui.dp(this,12));root.setBackgroundColor(Ui.BG);setContentView(root);
        TextView title=Ui.text(this,"Arena AI",25,Ui.TEXT);title.setTypeface(null,Typeface.BOLD);root.addView(title);root.addView(Ui.text(this,secrets.hasApiKey()?"Conectada · controle local + raciocínio + pesquisa web":"Local · configure IA conectada em Avançado para conversa livre",12,Ui.MUTED));
        LinearLayout quick=new LinearLayout(this);root.addView(quick,new LinearLayout.LayoutParams(-1,Ui.dp(this,44)));small(quick,"Status",()->handle("status"));small(quick,"Meta",()->handle("meta atual"));small(quick,"Explicar",()->handle("explica a última jogada"));
        scroll=new ScrollView(this);history=Ui.column(this);history.setPadding(0,Ui.dp(this,7),0,Ui.dp(this,8));scroll.addView(history);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout row=new LinearLayout(this);input=new EditText(this);input.setHint("Ex.: joga sozinho / meta atual / Spotify…");input.setHintTextColor(Ui.MUTED);input.setTextColor(Ui.TEXT);input.setSingleLine(false);input.setMaxLines(3);input.setBackground(Ui.shape(Ui.PANEL,Ui.dp(this,12)));input.setPadding(Ui.dp(this,12),Ui.dp(this,6),Ui.dp(this,12),Ui.dp(this,6));row.addView(input,new LinearLayout.LayoutParams(0,Ui.dp(this,54),1));
        Button send=new Button(this);send.setText("Enviar");send.setAllCaps(false);send.setTextColor(Ui.BG);send.setBackground(Ui.shape(Ui.ACCENT,Ui.dp(this,12)));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(Ui.dp(this,90),Ui.dp(this,54));sp.setMargins(Ui.dp(this,8),0,0,0);row.addView(send,sp);root.addView(row);send.setOnClickListener(v->submit());input.setOnEditorActionListener((v,a,e)->{submit();return true;});
    }
    private void small(LinearLayout p,String label,Runnable r){Button b=new Button(this);b.setText(label);b.setTextSize(11);b.setAllCaps(false);b.setTextColor(Ui.TEXT);b.setBackground(Ui.shape(Ui.PANEL_2,Ui.dp(this,10)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);lp.setMargins(Ui.dp(this,2),0,Ui.dp(this,2),0);p.addView(b,lp);b.setOnClickListener(v->r.run());}
    private void submit(){String q=input.getText().toString().trim();if(q.isEmpty())return;input.setText("");say("Você",q,true);handle(q);}
    private void handle(String raw){
        AgentCommands.Command c=AgentCommands.parse(raw);ArenaService s=ArenaService.instance;
        switch(c.type){
            case START_AUTO:
                if(s==null){say("Arena AI","Ative meu serviço de acessibilidade primeiro.",false);return;}String issue=ArenaService.readiness(store);if(!issue.isEmpty()){say("Arena AI","Ainda falta preparar o piloto:\n"+issue,false);return;}s.startSession(true);openClash();launchedGame=true;resumeOnExit=false;finish();return;
            case START_OBSERVE:
                if(s==null){say("Arena AI","Ative meu serviço de acessibilidade primeiro.",false);return;}s.startSession(false);openClash();launchedGame=true;resumeOnExit=false;finish();return;
            case PAUSE: if(s!=null)s.pauseSession("pedido no chat");resumeOnExit=false;say("Arena AI","Pausado.",false);return;
            case STOP: if(s!=null)s.stopSession("encerrado pelo chat",true);resumeOnExit=false;say("Arena AI","Sessão encerrada.",false);return;
            case STATUS: say("Arena AI",s!=null?s.snapshot():store.runtime(),false);return;
            case EXPLAIN: say("Arena AI",s!=null?s.explainLastDecision():store.decision(),false);return;
            case STYLE_BALANCED: setStyle(Core.STYLE_BALANCED);return;
            case STYLE_DEFENSIVE: setStyle(Core.STYLE_DEFENSIVE);return;
            case STYLE_AGGRESSIVE: setStyle(Core.STYLE_AGGRESSIVE);return;
            case META: research(c.argument.isEmpty()?"meta atual de Clash Royale, decks fortes no ladder e tendências dos últimos dias":c.argument);return;
            case YOUTUBE: handoff("YouTube",()->ExternalApps.youtube(this,c.argument.isEmpty()?"clash royale meta":c.argument));return;
            case WEB: if(c.argument.isEmpty()){say("Arena AI","Diga o que quer pesquisar.",false);return;}handoff("Chrome",()->ExternalApps.browser(this,c.argument));return;
            case SPOTIFY: if(c.argument.isEmpty()){say("Arena AI","Diga a música ou artista depois de Spotify.",false);return;}handoff("Spotify",()->ExternalApps.spotify(this,c.argument));return;
            case OPEN_CLASH: openClash();launchedGame=true;resumeOnExit=false;finish();return;
            case HELP: say("Arena AI",AgentCommands.help(),false);return;
            default: cloud(raw,false);return;
        }
    }
    private void setStyle(int style){store.setStyle(style);if(ArenaService.instance!=null)ArenaService.instance.setStyle(style);say("Arena AI","Estilo "+Core.styleName(style)+" ativado. Os limites de confiança, elixir e cooldown continuam obrigatórios.",false);}
    private void research(String q){if(!secrets.hasApiKey()){say("Arena AI","A IA conectada ainda não está configurada. Vou abrir uma busca no navegador; em Avançado você pode adicionar sua chave para eu pesquisar e resumir aqui dentro.",false);handoff("Chrome",()->ExternalApps.browser(this,q+" Clash Royale meta"));return;}cloud("Pesquise na web e faça um resumo prático e recente sobre: "+q+". Dê prioridade a dados atuais de decks, uso e desempenho; diferencie fato de recomendação.",true);}
    private void cloud(String prompt,boolean web){String key=secrets.apiKey();if(key.isEmpty()){say("Arena AI","Sem IA conectada. "+AgentCommands.help(),false);return;}String model=store.load().optString("aiModel","gpt-6-astra");say("Arena AI",web?"Pesquisando fontes recentes…":"Analisando…",false);String context=context();network.submit(()->{try{AiClient.Result result=new AiClient().ask(key,model,prompt,context,web);main.post(()->consumeAi(result));}catch(Exception e){main.post(()->say("Arena AI","Falha na IA conectada: "+e.getMessage(),false));}});}
    private void consumeAi(AiClient.Result result){String display=result.display();if(!display.isEmpty())say("Arena AI",display,false);for(AiClient.ToolCall call:result.tools)executeTool(call);}
    private void executeTool(AiClient.ToolCall call){ArenaService s=ArenaService.instance;String a=call.action;
        if("status".equals(a)){say("Arena AI",s!=null?s.snapshot():store.runtime(),false);return;}
        if("explain".equals(a)){say("Arena AI",s!=null?s.explainLastDecision():store.decision(),false);return;}
        if("set_style".equals(a)){String v=call.style;setStyle("defensive".equals(v)?Core.STYLE_DEFENSIVE:"aggressive".equals(v)?Core.STYLE_AGGRESSIVE:Core.STYLE_BALANCED);return;}
        if("start_auto".equals(a)||"start_observe".equals(a)){if(s==null){say("Arena AI","Ative meu serviço de acessibilidade primeiro.",false);return;}if("start_auto".equals(a)){String issue=ArenaService.readiness(store);if(!issue.isEmpty()){say("Arena AI","Ainda falta preparar o piloto:\n"+issue,false);return;}}s.startSession("start_auto".equals(a));openClash();launchedGame=true;resumeOnExit=false;finish();return;}
        if("pause".equals(a)){if(s!=null)s.pauseSession("pedido da Arena AI");resumeOnExit=false;say("Arena AI","Piloto pausado.",false);return;}
        if("stop".equals(a)){if(s!=null)s.stopSession("encerrado pela Arena AI",true);resumeOnExit=false;say("Arena AI","Sessão encerrada.",false);return;}
        if("open_clash".equals(a)){openClash();launchedGame=true;resumeOnExit=false;finish();return;}
        if("youtube".equals(a)){handoff("YouTube",()->ExternalApps.youtube(this,call.argument.isEmpty()?"clash royale meta":call.argument));return;}
        if("browser".equals(a)){if(call.argument.isEmpty()){say("Arena AI","Não recebi o assunto da pesquisa.",false);return;}handoff("Chrome",()->ExternalApps.browser(this,call.argument));return;}
        if("spotify".equals(a)){if(call.argument.isEmpty()){say("Arena AI","Não recebi a música ou artista.",false);return;}handoff("Spotify",()->ExternalApps.spotify(this,call.argument));return;}
        say("Arena AI","A IA pediu uma ação que não está na lista permitida; ignorei.",false);
    }
    private String context(){StringBuilder b=new StringBuilder();ArenaService s=ArenaService.instance;b.append("Estado do agente: ").append(s==null?store.runtime():s.snapshot()).append("\nDeck local: ");List<Core.Card>d=store.deck();if(d.isEmpty())b.append("não definido");else for(Core.Card c:d)b.append(c.name).append("(").append(c.elixir).append("), ");b.append("\nEstilo: ").append(Core.styleName(store.style())).append(". O motor de execução é local, não o modelo remoto.");return b.toString();}
    private void handoff(String name,Callable<Boolean> action){ArenaService s=ArenaService.instance;if(s!=null){if(resumeOnExit){s.resumeSession();resumeOnExit=false;}s.suspendForExternal(name);}externalLaunched=true;try{boolean ok=action.call();say("Arena AI",ok?"Abrindo "+name+". Quando você voltar ao Clash, o serviço pode retomar a sessão.":"Não consegui abrir "+name+".",false);}catch(Exception e){say("Arena AI","Não consegui abrir "+name+".",false);}}
    private void openClash(){Intent i=getPackageManager().getLaunchIntentForPackage(ArenaService.TARGET);if(i!=null)startActivity(i);}
    private void say(String who,String msg,boolean user){LinearLayout bubble=Ui.column(this);bubble.setPadding(Ui.dp(this,12),Ui.dp(this,8),Ui.dp(this,12),Ui.dp(this,9));bubble.setBackground(Ui.shape(user?Ui.ACCENT_DARK:Ui.PANEL,Ui.dp(this,14)));TextView h=Ui.text(this,who,11,user?Ui.ACCENT:Ui.MUTED);h.setTypeface(null,Typeface.BOLD);bubble.addView(h);TextView t=Ui.text(this,msg,14,Ui.TEXT);t.setAutoLinkMask(Linkify.WEB_URLS);t.setLinksClickable(true);bubble.addView(t);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(user?Ui.dp(this,42):0,Ui.dp(this,5),user?0:Ui.dp(this,18),Ui.dp(this,5));history.addView(bubble,p);main.post(()->scroll.fullScroll(View.FOCUS_DOWN));}
    @Override public void onDestroy(){network.shutdownNow();if(resumeOnExit&&!externalLaunched&&!launchedGame&&ArenaService.instance!=null)ArenaService.instance.resumeAfterAssistant();super.onDestroy();}
}
