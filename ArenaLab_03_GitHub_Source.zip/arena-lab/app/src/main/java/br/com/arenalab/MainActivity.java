package br.com.arenalab;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.widget.*;
import org.json.*;
import java.text.*;
import java.util.*;

/** Product-style home screen. Calibration and technical controls live in AdvancedActivity. */
public final class MainActivity extends Activity {
    private Store store;
    @Override public void onCreate(Bundle b){super.onCreate(b);store=new Store(this);show();}
    @Override public void onResume(){super.onResume();if(store!=null)show();}
    private void show(){
        LinearLayout root=Ui.page(this);JSONObject conf=store.load();
        Ui.heading(root,"Arena Lab","0.4 · autonomia visual + memória + Arena AI");
        LinearLayout hero=Ui.card(root);
        boolean service=ArenaService.instance!=null;String issues=ArenaService.readiness(store);boolean ready=issues.isEmpty();
        hero.addView(Ui.text(this,service?(ready?"● Pronto para pilotar":"● Serviço ativo · falta calibração"):"○ Ative a acessibilidade",19,service?Ui.ACCENT:Ui.TEXT));
        hero.addView(Ui.text(this,service?store.runtime():"O Arena Lab precisa do serviço de acessibilidade para observar a tela e executar gestos.",13,Ui.MUTED));
        if(!service)Ui.button(hero,"Ativar acessibilidade",()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        Ui.button(hero,"▶  Piloto automático",()->start(true));
        Ui.button(hero,"◉  Observar sem tocar",()->start(false));
        LinearLayout agent=Ui.card(root);agent.addView(Ui.text(this,"Agente",20,Ui.TEXT));
        agent.addView(Ui.text(this,"No modo Autonomia Total, o Arena Lab captura a própria tela, aprende cartas, memoriza estados e usa a IA conectada para navegar menus e pesquisar o meta sem você enviar prints.",13,Ui.MUTED));
        Ui.button(agent,"💬  Conversar com a Arena AI",()->startActivity(new Intent(this,AgentActivity.class)));
        LinearLayout style=Ui.card(root);style.addView(Ui.text(this,"Estilo de jogo · "+Core.styleName(store.style()),17,Ui.TEXT));
        LinearLayout row=new LinearLayout(this);style.addView(row);String[] labels={"Defensivo","Equilibrado","Agressivo"};int[] values={Core.STYLE_DEFENSIVE,Core.STYLE_BALANCED,Core.STYLE_AGGRESSIVE};
        for(int i=0;i<labels.length;i++){final int v=values[i];Button b=new Button(this);b.setText(labels[i]);b.setAllCaps(false);b.setTextSize(11);b.setTextColor(store.style()==v?Ui.ACCENT:Ui.TEXT);row.addView(b,new LinearLayout.LayoutParams(0,Ui.dp(this,46),1));b.setOnClickListener(x->{store.setStyle(v);if(ArenaService.instance!=null)ArenaService.instance.setStyle(v);show();});}
        LinearLayout online=Ui.card(root);online.addView(Ui.text(this,"Dados e meta",20,Ui.TEXT));
        long updated=conf.optLong("catalogUpdatedAt",0);online.addView(Ui.text(this,updated==0?"Catálogo local de emergência ativo.":"Catálogo online atualizado em "+new SimpleDateFormat("dd/MM HH:mm",Locale.getDefault()).format(new Date(updated)),13,Ui.MUTED));
        Ui.button(online,"Atualizar catálogo de cartas",()->CatalogSync.sync(this,(ok,msg)->{Ui.message(this,ok?"Atualizado":"Sem atualização",msg);show();}));
        Ui.button(online,"Pesquisar meta com Arena AI",()->{Intent i=new Intent(this,AgentActivity.class);i.putExtra("prompt","meta atual de Clash Royale: decks fortes, tendências e o que mudou recentemente");startActivity(i);});
        Ui.secondaryButton(online,"Abrir RoyaleAPI no navegador",()->open("https://royaleapi.com/decks/popular?lang=pt&type=Ladder&time=7d"));
        LinearLayout stats=Ui.card(root);int wins=conf.optInt("wins"),losses=conf.optInt("losses");stats.addView(Ui.text(this,"Sessões reconhecidas · "+wins+" V / "+losses+" D",16,Ui.TEXT));
        stats.addView(Ui.text(this,"Esses resultados são telemetria local, não uma promessa de taxa de vitória.",12,Ui.MUTED));
        Ui.button(stats,"⚙  Avançado",()->startActivity(new Intent(this,AdvancedActivity.class)));
    }
    private void start(boolean execute){
        if(ArenaService.instance==null){Ui.message(this,"Ative o serviço","Abra os ajustes de acessibilidade, ative Arena Lab e volte ao app.");return;}
        if(execute){String issue=ArenaService.readiness(store);if(!issue.isEmpty()){Ui.message(this,"Falta preparar o piloto",issue+"\n\nUse Avançado para ensinar o que falta.");return;}}
        Intent launch=getPackageManager().getLaunchIntentForPackage(ArenaService.TARGET);if(launch==null){Ui.message(this,"Clash não encontrado","Não encontrei com.supercell.clashroyale neste aparelho.");return;}
        ArenaService.instance.startSession(execute);startActivity(launch);
    }
    private void open(String url){try{if(ArenaService.instance!=null)ArenaService.instance.suspendForExternal("Pesquisa de meta");startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){Ui.message(this,"Não consegui abrir",e.getMessage());}}
}
