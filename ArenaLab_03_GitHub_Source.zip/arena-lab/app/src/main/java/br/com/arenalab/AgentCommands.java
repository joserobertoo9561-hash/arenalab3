package br.com.arenalab;

import java.text.Normalizer;
import java.util.*;

/** Local command router. Unknown text may be sent to the optional connected AI by AgentActivity. */
public final class AgentCommands {
    public enum Type { START_AUTO, START_OBSERVE, PAUSE, STOP, STATUS, EXPLAIN,
        STYLE_BALANCED, STYLE_DEFENSIVE, STYLE_AGGRESSIVE, META, YOUTUBE, WEB, SPOTIFY,
        OPEN_CLASH, HELP, UNKNOWN }
    public static final class Command {public final Type type;public final String argument;Command(Type t,String a){type=t;argument=a==null?"":a.trim();}}
    private static String n(String s){if(s==null)return "";s=Normalizer.normalize(s,Normalizer.Form.NFD).replaceAll("\\p{M}","").toLowerCase(Locale.ROOT).trim();return s.replaceAll("\\s+"," ");}
    public static Command parse(String raw){
        String s=n(raw);if(s.isEmpty())return new Command(Type.HELP,"");
        if(any(s,"joga sozinho","jogar sozinho","piloto automatico","modo automatico","autonomo","comeca a jogar","iniciar piloto","inicia o piloto","/jogar"))return new Command(Type.START_AUTO,"");
        if(any(s,"observar","modo observar","so observar","nao toque","nao joga","/observar"))return new Command(Type.START_OBSERVE,"");
        if(any(s,"pausa","pausar","para um pouco","/pausar"))return new Command(Type.PAUSE,"");
        if(any(s,"parar tudo","encerra","encerrar","fechar piloto","/parar"))return new Command(Type.STOP,"");
        if(any(s,"status","como voce esta","o que esta fazendo","/status"))return new Command(Type.STATUS,"");
        if(s.contains("por que")||s.contains("porque voce")||s.contains("explica")||s.contains("ultima jogada"))return new Command(Type.EXPLAIN,"");
        if(s.contains("defensiv"))return new Command(Type.STYLE_DEFENSIVE,"");
        if(s.contains("agressiv")||s.contains("ofensiv"))return new Command(Type.STYLE_AGGRESSIVE,"");
        if(s.contains("equilibrad")||s.contains("balancead"))return new Command(Type.STYLE_BALANCED,"");
        if(s.startsWith("/meta")){String a=raw.length()>5?raw.substring(5).trim():"";return new Command(Type.META,a);}
        if(s.equals("meta")||s.contains("meta atual")||s.contains("melhores decks")||s.contains("deck meta"))return new Command(Type.META,raw);
        if(s.startsWith("/youtube "))return new Command(Type.YOUTUBE,after(raw,' '));
        if(s.startsWith("youtube "))return new Command(Type.YOUTUBE,after(raw,' '));
        if(s.startsWith("youtube:"))return new Command(Type.YOUTUBE,raw.substring(Math.min(raw.length(),raw.indexOf(':')+1)).trim());
        if(s.contains("youtube")&&s.contains("meta"))return new Command(Type.YOUTUBE,"clash royale meta");
        if(s.startsWith("/spotify "))return new Command(Type.SPOTIFY,raw.substring(raw.indexOf(' ')+1));
        if(s.startsWith("spotify "))return new Command(Type.SPOTIFY,raw.substring(raw.indexOf(' ')+1));
        if(s.contains("spotify")&&(s.contains("toca")||s.contains("coloca")||s.contains("musica"))){int p=s.indexOf("spotify");String a=raw.substring(Math.min(raw.length(),p+7)).replaceFirst("^[ :,-]+","");return new Command(Type.SPOTIFY,a);}
        if(s.startsWith("/web ")||s.startsWith("/chrome "))return new Command(Type.WEB,raw.substring(raw.indexOf(' ')+1));
        if(s.startsWith("pesquisa ")||s.startsWith("pesquisar ")||s.startsWith("procura ")||s.startsWith("buscar ")||s.startsWith("chrome ")){int p=raw.indexOf(' ');return new Command(Type.WEB,p>=0?raw.substring(p+1):"");}
        if(s.contains("abre o clash")||s.contains("abrir clash")||s.equals("clash"))return new Command(Type.OPEN_CLASH,"");
        if(any(s,"ajuda","comandos","o que voce faz","/help","/ajuda"))return new Command(Type.HELP,"");
        return new Command(Type.UNKNOWN,raw);
    }
    private static String after(String raw,char delimiter){int p=raw.indexOf(delimiter);return p>=0?raw.substring(p+1).trim():"";}
    private static boolean any(String s,String... values){for(String v:values)if(s.equals(v)||s.contains(v))return true;return false;}
    public static String help(){return "Comandos: ‘joga sozinho’, ‘observar’, ‘pausar’, ‘modo defensivo/equilibrado/agressivo’, ‘status’, ‘explica a última jogada’, ‘meta atual’, ‘YouTube <busca>’, ‘pesquisar <assunto>’ e ‘Spotify <música>’. Com uma chave de API configurada, conversa livre e pesquisa de meta acontecem dentro do app.";}
}
