package br.com.arenalab;

import android.content.Context;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Refreshes public card metadata. Battle execution does not depend on this network call. */
public final class CatalogSync {
    public static final String SOURCE="https://royaleapi.github.io/cr-api-data/json/cards.json";
    public interface Callback { void done(boolean ok,String message); }
    public static void sync(Context context,Callback callback){
        Context app=context.getApplicationContext();
        new Thread(()->{
            HttpURLConnection c=null;
            try{
                c=(HttpURLConnection)new URL(SOURCE).openConnection();c.setConnectTimeout(8000);c.setReadTimeout(12000);c.setRequestProperty("User-Agent","ArenaLab/0.3");
                if(c.getResponseCode()!=200)throw new IOException("HTTP "+c.getResponseCode());
                ByteArrayOutputStream out=new ByteArrayOutputStream();byte[]buf=new byte[8192];int n;InputStream in=c.getInputStream();while((n=in.read(buf))>0&&out.size()<2_000_000)out.write(buf,0,n);in.close();
                JSONArray source=new JSONArray(new String(out.toByteArray(),StandardCharsets.UTF_8));JSONArray clean=new JSONArray();Set<String>seen=new HashSet<>();
                for(int i=0;i<source.length();i++){
                    JSONObject raw=source.optJSONObject(i);if(raw==null)continue;String id=raw.optString("key").trim();String name=raw.optString("name").trim();int elixir=raw.optInt("elixir",-1);String type=raw.optString("type");
                    if(id.isEmpty()||name.isEmpty()||elixir<0||elixir>10||!seen.add(id))continue;
                    JSONObject card=new JSONObject();Store.put(card,"id",id);Store.put(card,"name",name);Store.put(card,"elixir",elixir);Store.put(card,"roles",roles(id,name,type,elixir));clean.put(card);
                }
                if(clean.length()<80)throw new IOException("catálogo curto: "+clean.length());
                Store store=new Store(app);JSONObject conf=store.load();Store.put(conf,"remoteCatalog",clean);Store.put(conf,"catalogUpdatedAt",System.currentTimeMillis());Store.put(conf,"catalogSource",SOURCE);store.save(conf);
                app.getMainExecutor().execute(()->callback.done(true,"Catálogo atualizado: "+clean.length()+" cartas."));
            }catch(Exception e){app.getMainExecutor().execute(()->callback.done(false,"Não consegui atualizar agora: "+e.getMessage()));}
            finally{if(c!=null)c.disconnect();}
        },"arena-catalog").start();
    }
    private static int roles(String id,String name,String type,int elixir){
        String k=(id+" "+name).toLowerCase(Locale.ROOT);int r=0;
        if("Spell".equalsIgnoreCase(type)){r|=(elixir<=3?Core.SMALL_SPELL:Core.BIG_SPELL)|Core.SPLASH;return r;}
        if("Building".equalsIgnoreCase(type))r|=Core.BUILDING;
        if(has(k,"giant","golem","hog","balloon","ram rider","battle ram","royal hog","goblin barrel","graveyard","wall breaker","mortar","x-bow","xbow","goblin drill","lava hound","elixir golem","goblin giant"))r|=Core.WIN;
        if(has(k,"archer","musketeer","minion","dragon","wizard","witch","hunter","executioner","electro","firecracker","dart goblin","spear goblin","princess","magic archer","phoenix","mega minion","flying machine","zappies"))r|=Core.AIR;
        if(has(k,"bomber","valkyrie","wizard","witch","dragon","executioner","bowler","firecracker","baby dragon","skeleton dragon","royal ghost","dark prince"))r|=Core.SPLASH;
        if(has(k,"pekka","mini pekka","inferno","hunter","lumberjack","prince","barbarian","skeleton army","goblin gang","guards"))r|=Core.TANK_KILLER;
        if(has(k,"giant","golem","pekka","knight","valkyrie","mega knight","monk","golden knight","skeleton king","goblin giant","electro giant"))r|=Core.TANK;
        return r;
    }
    private static boolean has(String s,String... terms){for(String t:terms)if(s.contains(t))return true;return false;}
}
