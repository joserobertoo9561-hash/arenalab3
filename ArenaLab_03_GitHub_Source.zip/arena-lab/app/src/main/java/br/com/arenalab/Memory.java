package br.com.arenalab;

import android.content.Context;
import android.graphics.Bitmap;
import org.json.JSONObject;
import java.io.*;
import java.util.*;

/** Small private ring-buffer of key screenshots + structured events. Not a full video recorder. */
public final class Memory {
    private final Context ctx;private long lastFrame;private String lastTag="";
    public Memory(Context c){ctx=c.getApplicationContext();}
    public synchronized void frame(Bitmap image,String tag){long now=System.currentTimeMillis();if(tag==null)tag="state";if(tag.equals(lastTag)&&now-lastFrame<8000)return;lastFrame=now;lastTag=tag;File dir=new File(ctx.getFilesDir(),"memory");dir.mkdirs();File f=new File(dir,now+"_"+clean(tag)+".jpg");try(FileOutputStream out=new FileOutputStream(f)){image.compress(Bitmap.CompressFormat.JPEG,46,out);}catch(Exception ignored){}trim(dir,64);}
    public synchronized void event(String type,String text){try{File f=new File(ctx.getFilesDir(),"memory.ndjson");if(f.length()>900000)new FileOutputStream(f).close();JSONObject o=new JSONObject();Store.put(o,"time",System.currentTimeMillis());Store.put(o,"type",type);Store.put(o,"text",text==null?"":text);try(FileWriter w=new FileWriter(f,true)){w.write(o.toString());w.write("\n");}}catch(Exception ignored){}}
    public String tail(){try{byte[] b=java.nio.file.Files.readAllBytes(new File(ctx.getFilesDir(),"memory.ndjson").toPath());String s=new String(b,"UTF-8");return s.substring(Math.max(0,s.length()-10000));}catch(Exception e){return "Sem memória autônoma ainda.";}}
    private static void trim(File dir,int max){File[] fs=dir.listFiles((d,n)->n.endsWith(".jpg"));if(fs==null||fs.length<=max)return;Arrays.sort(fs,Comparator.comparingLong(File::lastModified));for(int i=0;i<fs.length-max;i++)fs[i].delete();}
    private static String clean(String s){return s.replaceAll("[^a-zA-Z0-9_-]","_").substring(0,Math.min(28,s.length()));}
}
