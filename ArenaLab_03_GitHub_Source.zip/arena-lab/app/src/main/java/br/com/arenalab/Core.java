package br.com.arenalab;

import java.util.*;

/**
 * Pure-Java decision core. The Android service owns perception and gesture dispatch;
 * this class only ranks safe, legal candidate plays.
 */
public final class Core {
    public static final int WIN=1, AIR=2, SPLASH=4, SMALL_SPELL=8, BIG_SPELL=16,
            TANK_KILLER=32, TANK=64, BUILDING=128;
    public static final int STYLE_BALANCED=0,STYLE_DEFENSIVE=1,STYLE_AGGRESSIVE=2;

    public static final class Card {
        public final String id, name;
        public final int elixir, roles;
        public boolean owned, ready;
        public int level=1, gold=0;
        public Card(String id,String name,int elixir,int roles){this.id=id;this.name=name;this.elixir=elixir;this.roles=roles;}
        public boolean has(int role){return (roles&role)!=0;}
    }

    public static List<Card> catalog(){
        List<Card> c=new ArrayList<>();
        c.add(new Card("giant","Gigante",5,WIN|TANK));
        c.add(new Card("knight","Cavaleiro",3,TANK));
        c.add(new Card("archers","Arqueiras",3,AIR));
        c.add(new Card("minipekka","Mini P.E.K.K.A",4,TANK_KILLER));
        c.add(new Card("musketeer","Mosqueteira",4,AIR));
        c.add(new Card("arrows","Flechas",3,SMALL_SPELL|SPLASH));
        c.add(new Card("fireball","Bola de Fogo",4,BIG_SPELL|SPLASH));
        c.add(new Card("goblins","Goblins",2,TANK_KILLER));
        c.add(new Card("speargoblins","Goblins Lanceiros",2,AIR));
        c.add(new Card("minions","Servos",3,AIR));
        c.add(new Card("bomber","Bombardeiro",2,SPLASH));
        c.add(new Card("valkyrie","Valquíria",4,SPLASH|TANK));
        c.add(new Card("skeletons","Esqueletos",1,TANK_KILLER));
        c.add(new Card("cannon","Canhão",3,BUILDING));
        c.add(new Card("hog","Corredor",4,WIN));
        c.add(new Card("zap","Zap",2,SMALL_SPELL));
        c.add(new Card("babydragon","Bebê Dragão",4,AIR|SPLASH));
        c.add(new Card("witch","Bruxa",5,AIR|SPLASH));
        c.add(new Card("wizard","Mago",5,AIR|SPLASH));
        c.add(new Card("pekka","P.E.K.K.A",7,TANK_KILLER|TANK));
        c.add(new Card("tesla","Tesla",4,AIR|BUILDING));
        c.add(new Card("inferno","Torre Inferno",5,AIR|BUILDING|TANK_KILLER));
        c.add(new Card("balloon","Balão",5,WIN));
        c.add(new Card("goblinbarrel","Barril de Goblins",3,WIN));
        return c;
    }

    public static Card byId(List<Card> cards,String id){for(Card c:cards)if(c.id.equals(id))return c;return null;}
    public static double average(List<Card> cards){double v=0;for(Card c:cards)v+=c.elixir;return cards.isEmpty()?0:v/cards.size();}
    public static int count(List<Card> cards,int role){int n=0;for(Card c:cards)if(c.has(role))n++;return n;}

    public static double deckScore(List<Card> deck){
        double score=0;
        for(Card c:deck)score+=Math.min(16,Math.max(1,c.level))*0.6;
        score+=Math.min(1,count(deck,WIN))*18;
        score+=Math.min(2,count(deck,AIR))*7;
        score+=Math.min(1,count(deck,SPLASH))*6;
        score+=Math.min(1,count(deck,SMALL_SPELL))*6;
        score+=Math.min(1,count(deck,BIG_SPELL))*5;
        score+=Math.min(1,count(deck,TANK_KILLER))*7;
        score+=Math.min(1,count(deck,TANK|BUILDING))*4;
        int spells=0,cheap=0;
        for(Card c:deck){if(c.has(SMALL_SPELL|BIG_SPELL))spells++;if(c.elixir<=2)cheap++;}
        score+=Math.min(2,cheap)*2;
        score-=Math.max(0,spells-2)*9;
        score-=Math.max(0,count(deck,WIN)-2)*7;
        score-=Math.abs(average(deck)-3.5)*5;
        return score;
    }

    public static List<Card> buildDeck(List<Card> catalog){
        List<Card> owned=new ArrayList<>();for(Card c:catalog)if(c.owned)owned.add(c);
        if(owned.size()<8)return Collections.emptyList();
        List<Card> best=null;
        for(Card seed:owned){
            List<Card> deck=new ArrayList<>();deck.add(seed);
            while(deck.size()<8){Card next=null;double value=-Double.MAX_VALUE;
                for(Card c:owned)if(!deck.contains(c)){deck.add(c);double score=deckScore(deck);deck.remove(c);if(score>value){value=score;next=c;}}
                if(next==null)break;deck.add(next);
            }
            boolean improved=true;int iterations=0;
            while(improved&&iterations++<30){improved=false;double score=deckScore(deck);
                outer:for(int i=0;i<deck.size();i++)for(Card replacement:owned)if(!deck.contains(replacement)){
                    Card old=deck.set(i,replacement);
                    if(deckScore(deck)>score+0.001){improved=true;break outer;}
                    deck.set(i,old);
                }
            }
            if(deck.size()==8&&(best==null||deckScore(deck)>deckScore(best)))best=new ArrayList<>(deck);
        }
        return best==null?Collections.emptyList():best;
    }

    public static Card nextUpgrade(List<Card> deck,int gold,int allowance,Set<String> completed){
        Card best=null;double bestValue=0;
        for(Card c:deck){
            if(!c.owned||!c.ready||c.gold<=0||c.gold>gold||c.gold>allowance||completed.contains(c.id))continue;
            double utility=10+Math.max(0,14-c.level)*3+(c.has(WIN)?16:0)+(c.has(AIR)?6:0)+(c.has(SMALL_SPELL|BIG_SPELL)?5:0);
            double score=utility/Math.sqrt(c.gold);
            if(score>bestValue){bestValue=score;best=c;}
        }
        return best;
    }

    public static final class Policy {
        public final String id,label;
        public final double attackElixir,attackWeight,defenseWeight,patience,cooldown;
        private Policy(String id,String label,double attackElixir,double attackWeight,double defenseWeight,double patience,double cooldown){
            this.id=id;this.label=label;this.attackElixir=attackElixir;this.attackWeight=attackWeight;this.defenseWeight=defenseWeight;this.patience=patience;this.cooldown=cooldown;
        }
    }

    public static Policy policy(String id){
        if("aggressive".equals(id))return new Policy("aggressive","Agressivo",7.8,1.28,.88,1.25,1.15);
        if("defensive".equals(id))return new Policy("defensive","Defensivo",9.5,.78,1.28,2.25,1.45);
        return new Policy("balanced","Equilibrado",8.9,1.0,1.0,1.75,1.30);
    }
    public static String strategyId(int style){return style==STYLE_AGGRESSIVE?"aggressive":style==STYLE_DEFENSIVE?"defensive":"balanced";}
    public static String styleName(int style){return policy(strategyId(style)).label;}

    public static final class State {
        public double elixir,confidence,leftThreat,rightThreat,leftUrgency,rightUrgency,leftX=.28,rightX=.72,leftY=.58,rightY=.58;
        /** Urgency is threat density weighted toward our towers, 0..approximately 1. */
        public boolean battle,geometryValid;
        public double threatPersistence;
        public double secondsSinceAction=99,battleSeconds,recentSpend;
        public int recentLane,previousLane,style=STYLE_BALANCED; // -1 left, +1 right, 0 unknown
        public String lastPlayedCard="";
        public final Card[] hand=new Card[4];
        public final double[] cardConfidence=new double[4];
    }

    public static final class Action {
        public final int slot,elixir;public final double x,y,score;public final String reason,cardId;
        public Action(int s,double x,double y,String r){this(s,x,y,0,r,0,"");}
        public Action(int s,double x,double y,double score,String r){this(s,x,y,score,r,0,"");}
        public Action(int s,double x,double y,double score,String r,int elixir,String cardId){slot=s;this.x=x;this.y=y;this.score=score;reason=r;this.elixir=elixir;this.cardId=cardId==null?"":cardId;}
    }

    public static Action choose(State s,double threshold){return choose(s,threshold,strategyId(s.style));}

    /**
     * v0.3 planner. It deliberately exposes a WAIT action by returning null. The planner
     * never bypasses recognition confidence, affordability, cooldown or arena geometry.
     */
    public static Action choose(State s,double threshold,String strategy){
        Policy p=policy(strategy);
        if(!s.battle||!s.geometryValid||s.confidence<threshold||s.elixir<1||s.secondsSinceAction<p.cooldown)return null;
        double leftSignal=s.leftThreat*(.60+.40*clamp01(s.leftUrgency));
        double rightSignal=s.rightThreat*(.60+.40*clamp01(s.rightUrgency));
        double threat=Math.max(leftSignal,rightSignal);
        boolean defend=threat>.00135&&s.threatPersistence>=.30;
        boolean left=leftSignal>=rightSignal;
        int chosen=-1;double best=-Double.MAX_VALUE;
        String bestReason="";

        for(int i=0;i<4;i++){
            Card c=s.hand[i];
            if(c==null||s.cardConfidence[i]<threshold||c.elixir>s.elixir)continue;
            double certainty=clamp01((s.cardConfidence[i]-threshold)/Math.max(.01,1-threshold));
            double v=certainty*1.65-c.elixir*.16-Math.min(1.8,s.recentSpend*.055);
            String reason;
            if(defend){
                double urgency=Math.min(2.8,threat*245.)*(.52+.48*s.threatPersistence)*p.defenseWeight;
                if(c.has(TANK_KILLER))v+=4.9*urgency;
                if(c.has(SPLASH))v+=4.25*urgency;
                if(c.has(BUILDING))v+=4.0*urgency;
                if(c.has(AIR))v+=2.15*urgency;
                if(c.has(TANK))v+=1.0*urgency;
                if(c.has(WIN))v-=4.4;
                if(c.has(SMALL_SPELL|BIG_SPELL))v-=threat<.006?2.1:0;
                if(threat<.004&&c.elixir>=5)v-=2.8;
                if(c.id.equals(s.lastPlayedCard)&&s.secondsSinceAction<4.0)v-=1.6;
                reason="defesa "+(left?"esquerda":"direita")+" persistente";
            }else{
                double minAttack=p.attackElixir;
                // Be extra patient in the opening seconds when vision has little history.
                if(s.battleSeconds<18)minAttack=Math.min(9.8,minAttack+.45);
                if(s.elixir<minAttack)continue;
                double attack=p.attackWeight;
                if(c.has(WIN))v+=7.6*attack;
                if(c.has(TANK))v+=2.15*attack;
                if(c.has(AIR))v+=.8*attack;
                if(c.elixir<=3)v+=1.25*attack;
                if(c.has(SMALL_SPELL|BIG_SPELL))v-=7.3;
                if(!c.has(WIN)&&!c.has(TANK)&&c.elixir>=5)v-=2.2;
                if(s.recentSpend>7)v-=2.0;
                if(c.id.equals(s.lastPlayedCard)&&s.secondsSinceAction<5.5)v-=1.8;
                reason="pressão calculada com elixir alto";
            }
            // A recent action lowers confidence in what the next screenshot already represents.
            if(s.secondsSinceAction<p.cooldown+.55)v-=3.8;
            if(v>best){best=v;chosen=i;bestReason=reason;}
        }

        double waitScore=defend?1.05*p.patience:1.9*p.patience;
        if(chosen<0||best<=waitScore)return null;
        Card c=s.hand[chosen];boolean spell=c.has(SMALL_SPELL|BIG_SPELL);
        double x=left?s.leftX:s.rightX,y=left?s.leftY:s.rightY;
        if(defend){
            if(c.has(BUILDING)){x=.50;y=.65;}
            else if(!spell){
                double urgency=left?clamp01(s.leftUrgency):clamp01(s.rightUrgency);
                y=Math.max(.59,Math.min(.79,y+.05+.07*urgency));
            }
        }else{
            // Prefer the quieter lane, but alternate when both are effectively equal.
            if(Math.abs(leftSignal-rightSignal)<.00035){int lane=s.recentLane!=0?s.recentLane:s.previousLane;x=lane<=0?.72:.28;}
            else x=leftSignal<=rightSignal?.28:.72;
            y=c.has(WIN)?.60:.75;
        }
        String reason=bestReason+" · "+p.label.toLowerCase(Locale.ROOT)+" · score="+String.format(Locale.ROOT,"%.2f",best);
        return new Action(chosen,x,y,best,reason,c.elixir,c.id);
    }

    private static double clamp01(double v){return Math.max(0,Math.min(1,v));}
    public static boolean safePoint(double x,double y){return Double.isFinite(x)&&Double.isFinite(y)&&x>.01&&x<.99&&y>.02&&y<.98;}
    public static boolean sameAspect(double a,double b){return a>0&&b>0&&Math.abs(a-b)<.018;}

    public static double imageSimilarity(double[] sample,double[] reference){
        if(sample==null||reference==null||sample.length!=reference.length||sample.length<12||sample.length%3!=0)return 0;
        double[] ma=new double[3],mb=new double[3];int pixels=sample.length/3;
        for(int i=0;i<sample.length;i++){ma[i%3]+=sample[i]/pixels;mb[i%3]+=reference[i]/pixels;}
        double va=0,vb=0,covariance=0,error=0;
        for(int i=0;i<sample.length;i++){double a=sample[i]-ma[i%3],b=reference[i]-mb[i%3];va+=a*a;vb+=b*b;covariance+=a*b;double e=sample[i]-reference[i];error+=e*e;}
        if(va/sample.length<.0004||vb/sample.length<.0004)return 0;
        double correlation=Math.max(0,Math.min(1,covariance/Math.sqrt(va*vb)));
        return Math.max(0,1-Math.sqrt(error/sample.length))*Math.sqrt(correlation);
    }
}
