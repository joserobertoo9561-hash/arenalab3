package br.com.arenalab;

import android.graphics.Bitmap;
import android.util.Base64;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;

/**
 * Multimodal observer used by full-autonomy mode.
 * It reads a screenshot, returns a compact structured state and at most one safe next action.
 * Battle fast-path remains local whenever the local recognizer is confident.
 */
public final class AutonomyClient {
    private static final String ENDPOINT="https://api.openai.com/v1/responses";

    public static final class Observation {
        public String scene="unknown",result="unknown",reason="",action="none",kind="",raw="";
        public double confidence,x=-1,y=-1,x2=-1,y2=-1,elixir=-1,leftThreat,rightThreat;
        public int slot=-1,gold=-1,costGold=0;
        public boolean safe,goalDone,inventoryComplete;
        public JSONArray cards=new JSONArray(),hand=new JSONArray(),deck=new JSONArray();
    }

    public Observation analyze(String key,String model,Bitmap source,String goal,String context) throws Exception {
        if(key==null||key.trim().isEmpty())throw new IllegalStateException("Chave de API não configurada");
        if(model==null||model.trim().isEmpty())model="gpt-6-astra";
        String image=dataUrl(source);
        JSONObject body=new JSONObject();
        body.put("model",model.trim());
        body.put("max_output_tokens",1100);
        body.put("store",false);
        JSONObject reasoning=new JSONObject();reasoning.put("effort","medium");body.put("reasoning",reasoning);
        body.put("instructions",instructions());

        JSONArray input=new JSONArray();JSONObject msg=new JSONObject();msg.put("role","user");JSONArray content=new JSONArray();
        JSONObject text=new JSONObject();text.put("type","input_text");text.put("text","OBJETIVO ATUAL: "+safe(goal)+"\nESTADO LOCAL: "+safe(context)+"\nAnalise somente esta captura e devolva um único JSON válido, sem markdown.");content.put(text);
        JSONObject img=new JSONObject();img.put("type","input_image");img.put("detail","low");img.put("image_url",image);content.put(img);msg.put("content",content);input.put(msg);body.put("input",input);

        HttpURLConnection c=(HttpURLConnection)new URL(ENDPOINT).openConnection();c.setRequestMethod("POST");c.setDoOutput(true);c.setConnectTimeout(20000);c.setReadTimeout(55000);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Authorization","Bearer "+key.trim());c.setRequestProperty("User-Agent","ArenaLab/0.4");
        byte[] bytes=body.toString().getBytes("UTF-8");c.setFixedLengthStreamingMode(bytes.length);try(OutputStream out=c.getOutputStream()){out.write(bytes);}int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();String raw=read(in);JSONObject response=new JSONObject(raw.isEmpty()?"{}":raw);
        if(code<200||code>=300){JSONObject e=response.optJSONObject("error");throw new IOException(e==null?"HTTP "+code:e.optString("message","HTTP "+code));}
        String output=outputText(response);if(output.isEmpty())throw new IOException("Resposta visual vazia");
        JSONObject j=parseObject(output);Observation o=new Observation();o.raw=output;
        o.scene=j.optString("scene","unknown");o.result=j.optString("result","unknown");o.reason=j.optString("reason","");o.confidence=j.optDouble("confidence",0);o.gold=j.optInt("gold",-1);o.elixir=j.optDouble("elixir",-1);o.leftThreat=j.optDouble("left_threat",0);o.rightThreat=j.optDouble("right_threat",0);o.inventoryComplete=j.optBoolean("inventory_complete");o.goalDone=j.optBoolean("goal_done");
        JSONArray cards=j.optJSONArray("cards");if(cards!=null)o.cards=cards;JSONArray hand=j.optJSONArray("hand");if(hand!=null)o.hand=hand;JSONArray deck=j.optJSONArray("deck");if(deck!=null)o.deck=deck;
        JSONObject a=j.optJSONObject("action");if(a!=null){o.action=a.optString("type","none");o.kind=a.optString("kind","");o.safe=a.optBoolean("safe");o.x=a.optDouble("x",-1);o.y=a.optDouble("y",-1);o.x2=a.optDouble("x2",-1);o.y2=a.optDouble("y2",-1);o.slot=a.optInt("slot",-1);o.costGold=a.optInt("cost_gold",0);String r=a.optString("reason");if(!r.isEmpty())o.reason=r;}
        return o;
    }

    private static String instructions(){return
        "Você é o módulo visual de um agente pessoal de Clash Royale. Identifique a tela e escolha no máximo UMA ação por captura. " +
        "Seu trabalho é operar menus e, se o motor local ainda não aprendeu a mão, sugerir uma jogada de batalha. " +
        "REGRAS DE SEGURANÇA: nunca compre ofertas, nunca use dinheiro real, nunca use gemas, nunca use chave/item mágico para acelerar baú e nunca confirme algo cujo custo não esteja claramente em OURO. " +
        "Uma melhoria de carta só pode ser marcada safe=true se o botão mostrar explicitamente custo em ouro e esse custo estiver em cost_gold. Recompensas grátis e abrir baú já desbloqueado são permitidos. " +
        "Não tente contornar detecção, anti-cheat, captcha ou bloqueios. Coordenadas são normalizadas de 0 a 1 na captura. " +
        "Em batalha, action.type=play usa slot 0..3 e x/y como ponto de implantação na tela; não use coordenadas fora da arena. " +
        "Para menus use tap ou swipe. Se não tiver certeza, use none. " +
        "Retorne EXATAMENTE um JSON com: scene (home|battle|victory|loss|collection|deck|reward|chest|menu|unknown), confidence 0..1, result (win|loss|unknown), gold inteiro ou -1, elixir 0..10 ou -1, left_threat 0..1, right_threat 0..1, " +
        "cards:[{id,name,level,owned,ready,gold_cost,x,y}], hand:[{slot,name}], deck:[nomes], inventory_complete boolean, goal_done boolean, " +
        "action:{type:none|tap|swipe|play,kind:string,safe:boolean,x,y,x2,y2,slot,cost_gold,reason}, reason:string. " +
        "Para cards/hand/deck, prefira SEMPRE o nome oficial em inglês quando reconhecer a carta; em cards inclua id/key oficial se souber. Não invente nível, ouro ou carta invisível.";
    }

    private static String dataUrl(Bitmap source) throws IOException {
        Bitmap b=source;int w=source.getWidth(),h=source.getHeight(),max=Math.max(w,h);if(max>1280){double s=1280.0/max;b=Bitmap.createScaledBitmap(source,Math.max(1,(int)(w*s)),Math.max(1,(int)(h*s)),true);}ByteArrayOutputStream out=new ByteArrayOutputStream();if(!b.compress(Bitmap.CompressFormat.JPEG,58,out))throw new IOException("Falha ao comprimir captura");if(b!=source)b.recycle();return "data:image/jpeg;base64,"+Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP);
    }
    private static String outputText(JSONObject json){StringBuilder b=new StringBuilder();JSONArray output=json.optJSONArray("output");if(output==null)return "";for(int i=0;i<output.length();i++){JSONObject item=output.optJSONObject(i);if(item==null||!"message".equals(item.optString("type")))continue;JSONArray content=item.optJSONArray("content");if(content==null)continue;for(int j=0;j<content.length();j++){JSONObject p=content.optJSONObject(j);if(p!=null&&"output_text".equals(p.optString("type"))){if(b.length()>0)b.append('\n');b.append(p.optString("text"));}}}return b.toString().trim();}
    private static JSONObject parseObject(String text) throws JSONException {int a=text.indexOf('{'),z=text.lastIndexOf('}');if(a<0||z<a)throw new JSONException("JSON visual ausente");return new JSONObject(text.substring(a,z+1));}
    private static String read(InputStream in) throws IOException {if(in==null)return "";ByteArrayOutputStream out=new ByteArrayOutputStream();byte[]buf=new byte[8192];for(int n;(n=in.read(buf))!=-1;)out.write(buf,0,n);in.close();return out.toString("UTF-8");}
    private static String safe(String s){if(s==null)return "";return s.length()>7000?s.substring(0,7000):s;}
}
