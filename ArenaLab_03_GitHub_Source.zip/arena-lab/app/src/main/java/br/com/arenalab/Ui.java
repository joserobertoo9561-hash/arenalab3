package br.com.arenalab;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;

public final class Ui {
    public static final int BG=Color.rgb(8,14,23),PANEL=Color.rgb(18,29,43),PANEL_2=Color.rgb(25,39,56),
            ACCENT=Color.rgb(101,225,194),ACCENT_DARK=Color.rgb(26,74,67),TEXT=Color.rgb(239,244,250),MUTED=Color.rgb(151,170,192),WARN=Color.rgb(255,188,94);
    public static int dp(Context c,float v){return (int)(v*c.getResources().getDisplayMetrics().density+.5);}
    public static GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    public static LinearLayout column(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);return l;}
    public static LinearLayout page(Activity a){ScrollView s=new ScrollView(a);s.setFillViewport(true);s.setBackgroundColor(BG);LinearLayout p=column(a);p.setPadding(dp(a,18),dp(a,20),dp(a,18),dp(a,30));s.addView(p);a.setContentView(s);a.getWindow().getDecorView().setOnApplyWindowInsetsListener((v,i)->{s.setPadding(0,i.getInsets(WindowInsets.Type.systemBars()).top,0,i.getInsets(WindowInsets.Type.systemBars()).bottom);return i;});return p;}
    public static TextView text(Context c,String value,int size,int color){TextView t=new TextView(c);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setPadding(0,dp(c,4),0,dp(c,6));return t;}
    public static void heading(LinearLayout parent,String title,String subtitle){TextView h=text(parent.getContext(),title,28,TEXT);h.setTypeface(null,Typeface.BOLD);parent.addView(h);parent.addView(text(parent.getContext(),subtitle,14,MUTED));}
    public static LinearLayout card(LinearLayout parent){Context c=parent.getContext();LinearLayout box=column(c);box.setPadding(dp(c,16),dp(c,13),dp(c,16),dp(c,15));box.setBackground(shape(PANEL,dp(c,18)));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(c,10),0,dp(c,5));parent.addView(box,p);return box;}
    public static Button button(LinearLayout parent,String label,Runnable action){return button(parent,label,action,true);}
    public static Button secondaryButton(LinearLayout parent,String label,Runnable action){return button(parent,label,action,false);}
    private static Button button(LinearLayout parent,String label,Runnable action,boolean primary){Context c=parent.getContext();Button b=new Button(c);b.setText(label);b.setAllCaps(false);b.setTextColor(primary?BG:TEXT);b.setTextSize(14);b.setBackground(shape(primary?ACCENT:PANEL_2,dp(c,12)));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(c,48));p.setMargins(0,dp(c,7),0,dp(c,3));parent.addView(b,p);b.setOnClickListener(v->action.run());return b;}
    public static EditText field(LinearLayout parent,String label,String value,boolean number){Context c=parent.getContext();parent.addView(text(c,label,13,MUTED));EditText e=new EditText(c);e.setText(value);e.setTextColor(TEXT);e.setHintTextColor(MUTED);e.setTextSize(16);e.setSingleLine(true);e.setPadding(dp(c,10),dp(c,5),dp(c,10),dp(c,5));e.setBackground(shape(PANEL_2,dp(c,8)));if(number)e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);parent.addView(e,new LinearLayout.LayoutParams(-1,dp(c,48)));return e;}
    public static int integer(EditText e,int fallback){try{return Math.max(0,Integer.parseInt(e.getText().toString()));}catch(Exception x){return fallback;}}
    public static CheckBox check(LinearLayout p,String label,boolean initial){CheckBox c=new CheckBox(p.getContext());c.setText(label);c.setTextColor(TEXT);c.setTextSize(14);c.setChecked(initial);p.addView(c);return c;}
    public static void message(Context c,String title,String body){new AlertDialog.Builder(c).setTitle(title).setMessage(body).setPositiveButton("Entendi",null).show();}
}
