# Arena Lab 0.4 Experimental

Protótipo Android de automação visual para Clash Royale.

## 0.4
- Autonomia Total sem calibração manual obrigatória.
- Capturas automáticas via AccessibilityService.
- Visão multimodal opcional via OpenAI Responses API.
- Leitura progressiva de coleção/níveis e memória local.
- Montagem de deck com cartas observadas.
- Pesquisa web periódica de meta quando habilitada.
- Navegação autônoma para deck, recompensas grátis, melhorias com ouro e partidas.
- Combate híbrido: visão remota para bootstrap/recuperação e motor local quando as cartas já foram aprendidas.
- Bloqueios explícitos para dinheiro real, ofertas, gemas, chaves e itens mágicos.

Automação pode violar as regras da Supercell e causar restrições/banimento. Use somente em ambiente de teste por sua conta e risco.
