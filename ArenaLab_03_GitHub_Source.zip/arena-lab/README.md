# Arena Lab 0.3 — piloto autônomo + Arena AI

Arena Lab 0.3 transforma o protótipo em um app Android com duas camadas independentes:

1. **Piloto local** — observa o Clash Royale, reconhece estado/mão/elixir/ameaça, decide jogadas e executa gestos somente quando o Clash está em primeiro plano.
2. **Arena AI** — chat opcional conectado à OpenAI Responses API para conversa livre, pesquisa web recente e ações de alto nível permitidas pelo app.

A jogabilidade não depende da nuvem. Se a chave de API não estiver configurada, o piloto continua funcionando e o chat mantém comandos locais.

## O que existe na 0.3

- Home simplificada com **Piloto automático**, **Observar**, **Arena AI**, estilo e dados/meta.
- Botão flutuante **IA** durante a sessão.
- Chat local em português: jogar, observar, pausar, parar, status, explicar jogada e trocar estilo.
- IA conectada opcional com **GPT-6 Astra**, `reasoning.effort=high`, `store=false`, pesquisa web e function calling.
- Ferramentas remotas permitidas: status, explicação, estilo, iniciar/observar/pausar/parar, abrir Clash, YouTube, navegador e Spotify.
- O modelo remoto **não recebe uma ferramenta de coordenadas**, não toca diretamente na tela e não recebe ferramenta de compra/melhoria/gasto.
- Pesquisa de meta dentro do chat usando `web_search`; URLs de fontes retornadas são exibidas no chat.
- YouTube e Chrome via intents Android. Gestos de acessibilidade continuam bloqueados fora do Clash.
- Spotify: tenta o intent Android de reprodução por busca; se o app não aceitar autoplay, cai para a busca no Spotify/web.
- Chave de API guardada criptografada com Android Keystore (AES-GCM). Ainda é uma credencial em app cliente: use uma chave/projeto com limites de gasto.
- Catálogo público de cartas atualizável por HTTPS, com fallback local.
- Três perfis: **Defensivo, Equilibrado e Agressivo**.
- Visão com amostragem direta de pixels, sem criar crops temporários por região.
- Estimativa de elixir por múltiplas linhas.
- Ameaça suavizada entre frames + urgência por proximidade.
- Mão com estabilidade temporal antes de permitir ação.
- Cooldown, gasto recente, lane anterior e carta anterior entram na decisão.
- Telemetria local: carta, lane, elixir, score e motivo.
- Automação de ciclo de sessão: equipar deck (se ensinado), iniciar batalha, jogar, reconhecer resultado, sair do resultado e repetir até os limites.
- Melhorias com ouro continuam **opt-in**, com orçamento manual e procedimento visual previamente ensinado.

## O que “autônomo” significa nesta versão

Depois da preparação inicial, o piloto consegue conduzir a sessão sozinho dentro do conjunto de telas/procedimentos que conhece. A preparação inicial ainda é necessária porque o protótipo não inclui um detector neural treinado com todas as telas, tropas e resoluções do Clash.

A 0.3 **não** promete:

- reconhecer perfeitamente cada tropa adversária;
- calcular HP individual ou elixir/ciclo adversário com precisão;
- aprender uma política competitiva sozinho com vitórias/derrotas;
- navegar livremente em qualquer app usando acessibilidade;
- assistir/entender vídeos do YouTube como uma pessoa;
- reproduzir Spotify automaticamente em todo aparelho/versão do app;
- taxa de vitória específica ou subida garantida de arena.

## Segurança operacional

- `ArenaService` verifica `com.supercell.clashroyale` antes de captura e antes de cada gesto.
- Ao abrir Arena AI, a sessão é pausada. Ao abrir Chrome/YouTube/Spotify, o piloto entra em suspensão externa.
- Function calling só aciona uma lista fechada de ações de alto nível.
- Nenhuma função conectada recebe coordenadas de toque.
- Compras, gemas e pagamentos ficam fora do projeto.
- Automação pode violar as regras da Supercell e provocar restrições/banimento.

## Arquitetura

| Arquivo | Responsabilidade |
| --- | --- |
| `Core.java` | catálogo local, montagem de deck, perfis e scoring de jogadas |
| `Vision.java` | reconhecimento por exemplos, elixir e ameaças |
| `ArenaService.java` | captura, memória temporal, macros, overlay e gestos |
| `AgentCommands.java` | roteamento offline em português |
| `AgentActivity.java` | chat e execução das ferramentas permitidas |
| `AiClient.java` | OpenAI Responses API, web search e function calling |
| `Secrets.java` | API key protegida por Android Keystore |
| `ExternalApps.java` | Chrome, YouTube e Spotify |
| `CatalogSync.java` | catálogo público de cartas |
| `MainActivity.java` | dashboard simples |
| `AdvancedActivity.java` | sessão, chave/modelo, deck, visão e procedimentos |
| `Store.java` | configurações, registros e telemetria |

## Testes desta entrega

- `CoreTest`: **3379** verificações, incluindo 200 cenários gerados de coleção/deck.
- `AgentCommandsTest`: **11** verificações.
- `static_check.py`: **14** checks de integração/arquitetura.
- Parsing Java: nenhum erro sintático detectado. A resolução completa de classes Android depende do `android.jar`.

O script `build_apk.py` compila, alinha, assina e verifica o APK quando Android Platform 35, Build Tools 35 e ECJ estão disponíveis (ou quando o ambiente permite baixá-los).
