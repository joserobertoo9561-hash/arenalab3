# Arena Lab 0.4 — Guia rápido

1. Instale e ative a Acessibilidade do Arena Lab.
2. Em Avançado > Sessão, configure sua OpenAI API key.
3. Ative **Autonomia Total**.
4. Defina limite de partidas, tempo e, se desejar, orçamento máximo de ouro para melhorias.
5. Ative/desative pesquisa automática, recompensas grátis e melhorias com ouro.
6. Volte e toque **Piloto automático**.

O app captura a própria tela; você não precisa mandar prints. Ele tenta ler coleção e níveis, montar/equipar deck, resgatar itens grátis, estudar meta e iniciar partidas. O primeiro aprendizado pode fazer várias chamadas de visão à API; depois, cartas já aprendidas podem ser reconhecidas localmente.

## Segurança
Ações com dinheiro real, ofertas, gemas, chaves, itens mágicos e aceleração paga ficam bloqueadas. Melhorias automáticas são permitidas apenas com ouro e dentro do orçamento configurado.

## Limites
A visão por IA pode errar e a interface do Clash muda. A versão 0.4 é experimental, não promete taxa de vitória e não tenta ocultar automação ou contornar anti-cheat.
