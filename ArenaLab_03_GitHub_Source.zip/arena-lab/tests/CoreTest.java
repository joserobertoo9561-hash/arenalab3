package br.com.arenalab;
import java.util.*;
public final class CoreTest {
    private static int checks;
    private static void check(boolean ok,String message){checks++;if(!ok)throw new AssertionError(message);}
    public static void main(String[]args){
        List<Core.Card> c=Core.catalog();check(Core.buildDeck(c).isEmpty(),"No invented ownership");
        for(int i=0;i<7;i++)c.get(i).owned=true;check(Core.buildDeck(c).isEmpty(),"Cannot form a seven-card deck");
        c.get(7).owned=true;List<Core.Card>d=Core.buildDeck(c);check(d.size()==8,"Eight available cards produce eight");check(Core.count(d,Core.WIN)>=1,"Starter deck retains a win condition");
        Random random=new Random(508);
        for(int pass=0;pass<200;pass++){
            List<Core.Card> inventory=Core.catalog();int owned=0;Set<String>available=new HashSet<>();
            for(Core.Card card:inventory){card.owned=random.nextBoolean();card.level=1+random.nextInt(16);if(card.owned){owned++;available.add(card.id);}}
            List<Core.Card>deck=Core.buildDeck(inventory);check(deck.size()==(owned>=8?8:0),"Deck size respects actual inventory");Set<String>ids=new HashSet<>();
            for(Core.Card card:deck){check(available.contains(card.id),"Deck never adds an unowned card");check(ids.add(card.id),"No duplicated deck cards");}
        }
        Core.Card giant=Core.byId(c,"giant");giant.ready=true;giant.gold=200;
        Core.Card archers=Core.byId(c,"archers");archers.ready=true;archers.gold=100;
        check(Core.nextUpgrade(d,50,1000,new HashSet<>())==null,"Cannot exceed balance");
        check(Core.nextUpgrade(d,1000,50,new HashSet<>())==null,"Cannot exceed session allowance");
        Set<String> done=new HashSet<>();done.add("archers");check(Core.nextUpgrade(d,150,150,done)==null,"Cannot retry a completed upgrade or pick an unaffordable one");
        Core.Card upgrade=Core.nextUpgrade(d,150,150,new HashSet<>());check(upgrade==archers,"Affordable alternative is selected");
        Core.State s=new Core.State();s.battle=true;s.geometryValid=true;s.confidence=.99;s.elixir=10;s.hand[0]=giant;s.cardConfidence[0]=.99;s.battleSeconds=30;
        check(Core.choose(s,.92)!=null,"Recognized affordable win condition can attack");
        s.elixir=4;check(Core.choose(s,.92)==null,"Will not spend unavailable elixir");s.elixir=10;s.confidence=.80;check(Core.choose(s,.92)==null,"Unknown scene cannot trigger a play");
        s.confidence=.99;s.cardConfidence[0]=.80;check(Core.choose(s,.92)==null,"Unknown hand card cannot trigger a play");s.cardConfidence[0]=.99;s.geometryValid=false;check(Core.choose(s,.92)==null,"Uncalibrated geometry cannot trigger a play");
        s.geometryValid=true;s.battle=false;check(Core.choose(s,.92)==null,"Menu cannot trigger a battle touch");
        s.battle=true;s.elixir=6;s.leftThreat=.006;s.leftUrgency=.8;s.threatPersistence=.9;s.secondsSinceAction=3;s.hand[1]=Core.byId(c,"minipekka");s.cardConfidence[1]=.99;Core.Action a=Core.choose(s,.92);check(a!=null&&a.slot==1,"Persistent defensive threat favors an affordable defender");check(Core.safePoint(a.x,a.y),"Defensive location is a finite in-arena point");
        s.threatPersistence=.1;check(Core.choose(s,.92)==null,"Single-frame threat is ignored");
        s.leftThreat=s.rightThreat=0;s.leftUrgency=s.rightUrgency=0;s.threatPersistence=0;s.elixir=8.2;s.secondsSinceAction=3;check(Core.choose(s,.92)==null,"Balanced mode waits below attack threshold");
        Core.Action aggressive=Core.choose(s,.92,"aggressive");check(aggressive!=null,"Aggressive mode may pressure earlier");
        check(Core.choose(s,.92,"defensive")==null,"Defensive mode remains patient");
        s.elixir=10;s.secondsSinceAction=.5;check(Core.choose(s,.92)==null,"Cooldown prefers waiting after a recent play");
        check(!Core.safePoint(Double.NaN,.5)&&!Core.safePoint(1.2,.4)&&!Core.safePoint(.4,-.3),"Reject invalid coordinates");
        check(Core.sameAspect(.45,.46)&&!Core.sameAspect(.45,.56),"Reject incompatible screen geometry");
        double[] flat=new double[768],pattern=new double[768],other=new double[768];
        for(int pixel=0;pixel<256;pixel++)for(int channel=0;channel<3;channel++){pattern[pixel*3+channel]=(pixel%16<5)? .85:.10;other[pixel*3+channel]=(pixel/16<5)? .85:.10;flat[pixel*3+channel]=.1;}
        check(Core.imageSimilarity(flat,flat)==0,"A uniform dark patch is not an actionable visual guard");
        check(Core.imageSimilarity(pattern,pattern)>.999,"Identical detailed example is recognized");
        check(Core.imageSimilarity(pattern,other)<.90,"Different shapes on matching dark backgrounds are rejected");
        check("aggressive".equals(Core.policy("aggressive").id)&&"defensive".equals(Core.policy("defensive").id)&&"balanced".equals(Core.policy("garbage").id),"Strategy profiles normalize safely");
        System.out.println("Core verification passed: "+checks+" assertions, including 200 inventory scenarios.");
    }
}
