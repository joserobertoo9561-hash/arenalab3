package br.com.arenalab;
public final class AgentCommandsTest {
  private static int n; private static void ok(boolean v){n++;if(!v)throw new AssertionError("falha "+n);}
  public static void main(String[] args){
    ok(AgentCommands.parse("joga sozinho").type==AgentCommands.Type.START_AUTO);
    ok(AgentCommands.parse("modo defensivo").type==AgentCommands.Type.STYLE_DEFENSIVE);
    ok(AgentCommands.parse("Explica a última jogada").type==AgentCommands.Type.EXPLAIN);
    ok(AgentCommands.parse("meta atual").type==AgentCommands.Type.META);
    ok(AgentCommands.parse("/meta deck pekka").argument.contains("pekka"));
    ok(AgentCommands.parse("pesquisar deck pekka").type==AgentCommands.Type.WEB);
    ok(AgentCommands.parse("YouTube clash royale").type==AgentCommands.Type.YOUTUBE);
    ok(AgentCommands.parse("YouTube:deck pekka").argument.equals("deck pekka"));
    ok(AgentCommands.parse("Spotify Billie Eilish").type==AgentCommands.Type.SPOTIFY);
    ok(AgentCommands.parse("status").type==AgentCommands.Type.STATUS);
    ok(AgentCommands.parse("qualquer coisa aleatória").type==AgentCommands.Type.UNKNOWN);
    System.out.println("AgentCommands: "+n+" verificações passaram.");
  }
}
