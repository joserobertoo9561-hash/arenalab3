from pathlib import Path
r=Path(__file__).resolve().parents[1]
java=r/'app/src/main/java/br/com/arenalab'
manifest=(r/'app/src/main/AndroidManifest.xml').read_text()
ai=(java/'AiClient.java').read_text(); agent=(java/'AgentActivity.java').read_text(); service=(java/'ArenaService.java').read_text(); store=(java/'Store.java').read_text(); ext=(java/'ExternalApps.java').read_text()
checks={
'0.3 manifest':'versionName="0.3-experimental"' in manifest,
'internet declared':'android.permission.INTERNET' in manifest,
'spotify query':'com.spotify.music' in manifest,
'chrome query':'com.android.chrome' in manifest,
'OpenAI Responses':'https://api.openai.com/v1/responses' in ai,
'current Astra default':'gpt-6-astra' in ai,
'web search tool':'web_search' in ai,
'allowlisted function':'arena_action' in ai,
'no API storage':'body.put("store",false)' in ai,
'high reasoning':'reasoning.put("effort","high")' in ai,
'cloud tool execution':'executeTool(AiClient.ToolCall' in agent,
'gesture target gate':'TARGET.equals(foregroundPackage())' in service,
'only one Store style getter':store.count('public int style()')==1,
'spotify media intent':'INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH' in ext,
}
for k,v in checks.items():
    if not v: raise SystemExit('FAIL: '+k)
print('Static integration checks:',len(checks),'passaram.')
