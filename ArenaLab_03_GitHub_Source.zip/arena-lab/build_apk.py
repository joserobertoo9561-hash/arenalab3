#!/usr/bin/env python3
"""Compile this dependency-free Java Android prototype without Gradle."""
from pathlib import Path
import hashlib
import os
import shutil
import subprocess
import sys
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent
TOOLS = Path(os.environ.get("ARENA_BUILD_TOOLS", ROOT.parent / "tools-android")).resolve()
BUILD = ROOT / "build"
OUTPUT = Path(os.environ.get("ARENA_OUTPUT", ROOT.parent / "deliverables")).resolve()
URLS = {
    "platform.zip": "https://dl.google.com/android/repository/platform-35_r02.zip",
    "build-tools.zip": "https://dl.google.com/android/repository/build-tools_r35.0.1_linux.zip",
    "ecj.jar": "https://repo.maven.apache.org/maven2/org/eclipse/jdt/ecj/3.38.0/ecj-3.38.0.jar",
}

def run(*args):
    subprocess.run([str(x) for x in args], check=True, cwd=ROOT)

def prepare():
    TOOLS.mkdir(parents=True, exist_ok=True)
    for name, url in URLS.items():
        dest = TOOLS / name
        if not dest.exists():
            with urllib.request.urlopen(url, timeout=90) as response, dest.open("wb") as out:
                shutil.copyfileobj(response, out)
    sdk = TOOLS / "sdk"
    if not (sdk / "android-35" / "android.jar").exists() or not (sdk / "android-15" / "aapt2").exists():
        for name in ("platform.zip", "build-tools.zip"):
            with zipfile.ZipFile(TOOLS / name) as z:
                z.extractall(sdk)
                for item in z.infolist():
                    mode = item.external_attr >> 16
                    if mode & 0o111:
                        (sdk / item.filename).chmod(mode)
    return sdk

def tests(android_jar):
    test_dir = BUILD / "tests"
    test_dir.mkdir(parents=True, exist_ok=True)
    run("java", "-jar", TOOLS / "ecj.jar", "-8", "-d", test_dir,
        ROOT / "app/src/main/java/br/com/arenalab/Core.java", ROOT / "tests/CoreTest.java",
        ROOT / "app/src/main/java/br/com/arenalab/AgentCommands.java", ROOT / "tests/AgentCommandsTest.java")
    run("java", "-cp", test_dir, "br.com.arenalab.CoreTest")
    run("java", "-cp", test_dir, "br.com.arenalab.AgentCommandsTest")

def main():
    sdk = prepare()
    tools = sdk / "android-15"
    android_jar = sdk / "android-35/android.jar"
    BUILD.mkdir(exist_ok=True)
    OUTPUT.mkdir(parents=True, exist_ok=True)
    tests(android_jar)
    generated, classes, dex = BUILD / "generated", BUILD / "classes", BUILD / "dex"
    for directory in (generated, classes, dex):
        if directory.exists():
            shutil.rmtree(directory)
        directory.mkdir()
    run(tools / "aapt2", "compile", "--dir", ROOT / "app/src/main/res", "-o", BUILD / "resources.zip")
    run(tools / "aapt2", "link", "-I", android_jar, "--manifest", ROOT / "app/src/main/AndroidManifest.xml",
        "--java", generated, "--min-sdk-version", "30", "--target-sdk-version", "35",
        "-o", BUILD / "unsigned.apk", BUILD / "resources.zip")
    sources = sorted((ROOT / "app/src/main/java").rglob("*.java")) + sorted(generated.rglob("*.java"))
    run("java", "-jar", TOOLS / "ecj.jar", "-8", "-warn:none", "-classpath", android_jar, "-d", classes, *sources)
    with zipfile.ZipFile(BUILD / "classes.jar", "w", zipfile.ZIP_DEFLATED) as z:
        for path in sorted(classes.rglob("*.class")):
            z.write(path, path.relative_to(classes).as_posix())
    run(tools / "d8", "--lib", android_jar, "--min-api", "30", "--output", dex, BUILD / "classes.jar")
    with zipfile.ZipFile(BUILD / "unsigned.apk", "a", zipfile.ZIP_STORED) as z:
        for path in sorted(dex.glob("*.dex")):
            z.write(path, path.name)
    run(tools / "zipalign", "-f", "4", BUILD / "unsigned.apk", BUILD / "aligned.apk")
    key = BUILD / "prototype-keystore.p12"
    if not key.exists():
        run("keytool", "-genkeypair", "-keystore", key, "-alias", "arena-lab", "-keyalg", "RSA", "-keysize", "3072",
            "-validity", "3650", "-storepass", "arena-lab-testing-only", "-keypass", "arena-lab-testing-only",
            "-dname", "CN=Arena Lab Experimental")
    apk = OUTPUT / "ArenaLab_03_Experimental.apk"
    run(tools / "apksigner", "sign", "--ks", key, "--ks-pass", "pass:arena-lab-testing-only",
        "--key-pass", "pass:arena-lab-testing-only", "--out", apk, BUILD / "aligned.apk")
    run(tools / "apksigner", "verify", "--verbose", apk)
    run(tools / "zipalign", "-c", "4", apk)
    (OUTPUT / "ArenaLab_SHA256.txt").write_text(hashlib.sha256(apk.read_bytes()).hexdigest()+"  "+apk.name+"\n", encoding="utf-8")
    print(f"APK ready: {apk} ({apk.stat().st_size:,} bytes)")

if __name__ == "__main__":
    main()
