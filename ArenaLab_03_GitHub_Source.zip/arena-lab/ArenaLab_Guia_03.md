# Arena Lab 0.3 — guia rápido

## 1. Preparação inicial

1. Instale uma build da 0.3 e ative **Arena Lab** em Acessibilidade.
2. Abra **Avançado > Deck**, marque as cartas da conta de teste, monte o deck e registre que ele está equipado; ou ensine os procedimentos de equipar.
3. Em **Avançado > Visão**, rode primeiro em **Observar**. No Clash, use `◎` para ensinar início, batalha, vitória, derrota, as oito cartas do deck, arena, quatro slots da mão e barra de elixir.
4. Em **Avançado > Menus**, ensine pelo menos `battle.start` e `result.dismiss`. Se quiser deck automático, ensine também os oito procedimentos `equip` do deck atual.
5. Confira o modo **Observar** e a telemetria antes de liberar gestos.

Essa preparação ainda existe porque a 0.3 não contém um detector neural universal treinado com todas as telas e tropas do Clash.

## 2. Uso normal

Na home, toque **Piloto automático**. Depois da calibração, o ciclo pode seguir sozinho: início → batalha → resultado → sair do resultado → próxima batalha, até atingir os limites da sessão.

O overlay tem:

- `⏯` — pausar/retomar;
- `IA` — abrir Arena AI;
- `◎` — capturar exemplo para ensino;
- `✕` — encerrar sessão e remover overlay.

A tela **Avançado > Sessão** permite limitar partidas, minutos e confiança visual. Melhorias com ouro são opcionais e têm orçamento separado.

## 3. Arena AI offline

Mesmo sem API, o chat entende comandos como:

- `joga sozinho`
- `observar`
- `pausa`
- `parar tudo`
- `status`
- `explica a última jogada`
- `modo defensivo`
- `modo equilibrado`
- `modo agressivo`
- `meta atual` (abre busca se a IA conectada não estiver configurada)
- `YouTube clash royale meta`
- `pesquisar melhor deck P.E.K.K.A`
- `Spotify Billie Eilish`

## 4. Arena AI conectada

Em **Avançado > Sessão > Arena AI conectada**, informe sua própria OpenAI API key. A chave é criptografada pelo Android Keystore. Como continua sendo uma credencial dentro de um app cliente, use limites de gasto no projeto/chave.

A configuração padrão desta fonte usa:

- Responses API;
- `gpt-6-astra`;
- raciocínio `high`;
- `store=false`;
- `web_search` quando você pede pesquisa recente;
- function calling para um conjunto fechado de ações do Arena Lab.

A IA pode pedir ao app: status, explicação, mudança de estilo, iniciar/observar/pausar/parar, abrir Clash, YouTube, navegador ou Spotify. **Ela não recebe uma função de coordenadas nem de compra/melhoria.** A execução da partida permanece no motor Android local.

## 5. Meta, Chrome e YouTube

`meta atual` usa pesquisa web dentro da Arena AI quando a chave está configurada e exibe as URLs citadas. Sem chave, abre uma pesquisa normal no navegador.

YouTube/Chrome são abertos apenas quando solicitado. O serviço de acessibilidade não usa gestos nesses aplicativos; a sessão fica suspensa fora do Clash.

## 6. Spotify

`Spotify <música ou artista>` tenta primeiro o intent Android de reprodução por busca no app do Spotify. A resposta do Spotify varia entre aparelhos/versões/contas; se ele não reproduzir diretamente, o Arena Lab abre a busca correspondente. Isso é **best effort**, não garantia de autoplay.

## 7. Limites importantes

A percepção de combate ainda é heurística. Ela reconhece mão por exemplos, estima elixir e mede ameaça/urgência, mas ainda não identifica perfeitamente todas as tropas adversárias nem calcula ciclo/elixir do oponente. O próximo salto técnico seria um detector treinado de unidades/torres + rastreamento temporal de estado.

Automação pode contrariar as regras da Supercell e causar restrições ou banimento. Não existe garantia de isolamento entre uma conta de teste e sua conta principal.
